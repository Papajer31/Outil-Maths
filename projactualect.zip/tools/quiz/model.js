import { normalizeQuizImageSource } from "../../shared/quiz-local-image-store.js";
import { normalizeQuizAudioSource } from "../../shared/quiz-audio-source.js";
import {
  formatQuizSelectionIndexes,
  getQuizSelectionWordCount,
  normalizeQuizSelectionIndexes
} from "../../shared/quiz-selection-text.js";

import {
  DEFAULT_QUESTION_SELECTION_MODE,
  filterItemsByQuestionSelection,
  getItemSelectionKey,
  getQuestionSelectionSignature as getCommonQuestionSelectionSignature,
  normalizeQuestionSelection as normalizeCommonQuestionSelection
} from "../../shared/tool-commons/general-tools/question-selection.js";

const GRID_COLUMNS = 12;
const GRID_ROWS = 8;
const DEFAULT_DRAW_MODE = "random";
const DEFAULT_VARIANT_DRAW_MODE = "in_order";
const DRAW_MODES = new Set(["in_order", "random"]);
const SUPPORTED_WIDGET_TYPES = new Set(["text", "masked-text", "flash-text", "answer", "verified-answer", "done", "image", "flash-image", "audio", "labels", "numeric-keypad", "qcm-text", "selection-words", "categories"]);
const QCM_LAYOUTS = new Set(["auto", "row", "column", "grid"]);
const QUIZ_FONT_SIZES = new Set(["small", "normal", "large", "huge"]);
const QCM_MIN_CHOICES = 2;
const QCM_MAX_CHOICES = 6;
const CORRECTION_VISIBILITY_MODES = new Set(["visible", "correct", "incorrect", "hidden"]);
const normalizedQuizSnapshots = new WeakSet();

function normalizeFlashDelaySeconds(value){
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 5;
  return Math.max(0, Math.min(60, Math.round(numeric)));
}

function normalizeFlashVisibleSeconds(value){
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 3;
  return Math.max(0.5, Math.min(60, Math.round(numeric * 2) / 2));
}

function normalizeLabelItems(sourceItems, widgetIndex = 0){
  const source = Array.isArray(sourceItems) ? sourceItems : [];
  return source.map((item, index) => {
    const safe = item && typeof item === "object" && !Array.isArray(item) ? item : { text:item };
    return {
      id:String(safe.id || `labels-${widgetIndex + 1}-item-${index + 1}`).trim() || `labels-${widgetIndex + 1}-item-${index + 1}`,
      text:String(safe.text ?? safe.label ?? "")
    };
  });
}

function normalizeCategoryItems(sourceItems, widgetIndex = 0){
  const source = Array.isArray(sourceItems) ? sourceItems : [];
  return source.map((item, index) => {
    const safe = item && typeof item === "object" && !Array.isArray(item) ? item : { title:item };
    return {
      id:String(safe.id || `categories-${widgetIndex + 1}-item-${index + 1}`).trim() || `categories-${widgetIndex + 1}-item-${index + 1}`,
      title:String(safe.title ?? safe.label ?? `Catégorie ${index + 1}`),
      labelIds:Array.from(new Set((Array.isArray(safe.labelIds ?? safe.label_ids) ? (safe.labelIds ?? safe.label_ids) : [])
        .map((value) => String(value || "").trim())
        .filter(Boolean)))
    };
  });
}

function getCategoryAssignments(labelItems = [], categoryItems = []){
  const validLabelIds = new Set(normalizeLabelItems(labelItems)
    .filter((item) => String(item.text || "").trim())
    .map((item) => item.id));
  const assignments = {};
  const duplicates = new Set();
  normalizeCategoryItems(categoryItems).forEach((category) => {
    category.labelIds.forEach((labelId) => {
      if (!validLabelIds.has(labelId)) return;
      if (assignments[labelId]) duplicates.add(labelId);
      else assignments[labelId] = category.id;
    });
  });
  const missing = Array.from(validLabelIds).filter((labelId) => !assignments[labelId]);
  return { assignments, duplicates, missing };
}

function normalizeCategoryAnswerMap(value){
  let source = value;
  if (typeof source === "string") {
    try { source = JSON.parse(source); } catch { source = {}; }
  }
  const safe = source && typeof source === "object" && !Array.isArray(source) ? source : {};
  return Object.fromEntries(Object.entries(safe)
    .map(([labelId, categoryId]) => [String(labelId || "").trim(), String(categoryId || "").trim()])
    .filter(([labelId, categoryId]) => labelId && categoryId)
    .sort(([left], [right]) => left.localeCompare(right)));
}

function serializeCategoryAnswerMap(value){
  return JSON.stringify(normalizeCategoryAnswerMap(value));
}

export function getDefaultQuizRuntimeSettings(){
  return {
    drawMode: DEFAULT_DRAW_MODE,
    questionSelection: { mode: DEFAULT_QUESTION_SELECTION_MODE, questionKeys: [] },
    timeLimitSec: 0,
    autoExitOnComplete: false
  };
}

export function normalizeQuizRuntimeSettings(settings = {}, snapshot = null){
  const safe = settings && typeof settings === "object" && !Array.isArray(settings) ? settings : {};
  const drawMode = DRAW_MODES.has(String(safe.drawMode || safe.draw_mode || "").trim())
    ? String(safe.drawMode || safe.draw_mode).trim()
    : DEFAULT_DRAW_MODE;
  const questionSelection = normalizeQuestionSelection(safe.questionSelection || safe.question_selection || {});
  const timeLimitSec = Math.max(0, Math.min(3600, Math.trunc(Number(safe.timeLimitSec ?? safe.time_limit_sec) || 0)));
  const autoExitOnComplete = safe.autoExitOnComplete === true || safe.auto_exit_on_complete === true;
  return {
    drawMode,
    questionSelection: snapshot
      ? normalizeQuizSelectionForSnapshot(snapshot, questionSelection)
      : questionSelection,
    timeLimitSec,
    autoExitOnComplete
  };
}

export function getDefaultSettings(){
  return {
    quizId: "",
    quizTitle: "",
    ...getDefaultQuizRuntimeSettings(),
    quizSnapshot: {
      version: 1,
      id: "",
      title: "",
      instruction: "",
      runtimeSettings: getDefaultQuizRuntimeSettings(),
      grid: { columns: GRID_COLUMNS, rows: GRID_ROWS },
      questions: []
    }
  };
}

export function normalizeSettings(settings = {}){
  const safe = settings && typeof settings === "object" && !Array.isArray(settings) ? settings : {};
  const drawMode = DRAW_MODES.has(String(safe.drawMode || safe.draw_mode || "").trim())
    ? String(safe.drawMode || safe.draw_mode).trim()
    : DEFAULT_DRAW_MODE;
  const snapshot = normalizeQuizSnapshot(safe.quizSnapshot || safe.quiz_snapshot || safe.snapshot || {});
  const sourceInstruction = String(
    safe.sourceInstruction
    ?? safe.source_instruction
    ?? safe.quizInstruction
    ?? safe.quiz_instruction
    ?? snapshot.instruction
    ?? ""
  ).trim();

  const runtimeSettings = normalizeQuizRuntimeSettings({
    drawMode,
    questionSelection: safe.questionSelection || safe.question_selection || {},
    timeLimitSec: safe.timeLimitSec ?? safe.time_limit_sec ?? snapshot.runtimeSettings?.timeLimitSec,
    autoExitOnComplete: safe.autoExitOnComplete ?? safe.auto_exit_on_complete ?? snapshot.runtimeSettings?.autoExitOnComplete
  }, snapshot);

  return {
    ...getDefaultSettings(),
    ...safe,
    quizId: String(safe.quizId || safe.quiz_id || snapshot.id || "").trim(),
    quizTitle: String(safe.quizTitle || safe.quiz_title || snapshot.title || "").trim(),
    sourceInstruction,
    drawMode: runtimeSettings.drawMode,
    questionSelection: runtimeSettings.questionSelection,
    timeLimitSec: runtimeSettings.timeLimitSec,
    autoExitOnComplete: runtimeSettings.autoExitOnComplete,
    quizSnapshot: snapshot
  };
}

export function normalizeQuizSnapshot(snapshot = {}){
  if (snapshot && typeof snapshot === "object" && !Array.isArray(snapshot) && normalizedQuizSnapshots.has(snapshot)) {
    return snapshot;
  }
  const safe = snapshot && typeof snapshot === "object" && !Array.isArray(snapshot) ? snapshot : {};
  const sourceColumns = Math.max(1, Math.trunc(Number(safe.grid?.columns) || GRID_COLUMNS));
  const questions = (Array.isArray(safe.questions) ? safe.questions : [])
    .map((question, index) => normalizeQuizQuestion(question, index, sourceColumns))
    .filter((question) => question.widgets.length > 0);
  const editorMode = String(safe.editorMode ?? safe.editor_mode ?? "").trim();
  const seriesModelId = String(safe.seriesModelId ?? safe.series_model_id ?? "").trim();
  const declaredInstruction = String(
    safe.instruction
    ?? safe.generalInstruction
    ?? safe.general_instruction
    ?? ""
  ).trim();

  const runtimeSettings = normalizeQuizRuntimeSettings(
    safe.runtimeSettings ?? safe.runtime_settings ?? {
      drawMode: safe.drawMode ?? safe.draw_mode,
      questionSelection: safe.questionSelection ?? safe.question_selection
    }
  );

  const normalized = {
    version: Math.max(1, Math.trunc(Number(safe.version) || 1)),
    id: String(safe.id || "").trim(),
    title: String(safe.title || "").trim(),
    // Les premières séries ne possédaient pas encore de propriété `instruction`.
    // Leur consigne commune est le premier widget texte, répété dans chaque variante.
    instruction: declaredInstruction || (
      editorMode === "series" || Boolean(seriesModelId)
        ? getSeriesInstructionFromQuestions(questions)
        : ""
    ),
    editorMode,
    seriesModelId,
    runtimeSettings,
    grid: { columns: GRID_COLUMNS, rows: GRID_ROWS },
    questions
  };
  normalizedQuizSnapshots.add(normalized);
  return normalized;
}

function getSeriesInstructionFromQuestions(questions = []){
  const firstQuestion = Array.isArray(questions) ? questions[0] : null;
  if (!firstQuestion) return "";

  const variant = materializeQuizQuestionVariant(firstQuestion, 0);
  const instructionWidget = (variant.widgets || [])
    .filter((widget) => widget?.type === "text")
    .sort((left, right) => {
      const rowDifference = Number(left?.row || 0) - Number(right?.row || 0);
      return rowDifference || Number(left?.column || 0) - Number(right?.column || 0);
    })
    .find((widget) => getWidgetView(widget, "question")?.visible !== false);

  return String(getWidgetView(instructionWidget, "question")?.text || "").trim();
}

export function normalizeQuizQuestion(question = {}, index = 0, sourceColumns = GRID_COLUMNS){
  const safe = question && typeof question === "object" && !Array.isArray(question) ? question : {};
  const timerSeconds = Math.max(0, Math.min(300, Math.trunc(Number(safe.timerSeconds ?? safe.timer_seconds) || 0)));
  const variantDrawMode = DRAW_MODES.has(String(safe.variantDrawMode ?? safe.variant_draw_mode ?? "").trim())
    ? String(safe.variantDrawMode ?? safe.variant_draw_mode).trim()
    : DEFAULT_VARIANT_DRAW_MODE;
  const widgets = (Array.isArray(safe.widgets) ? safe.widgets : [])
    .map((widget, widgetIndex) => normalizeQuizWidget(widget, widgetIndex, sourceColumns))
    .filter(Boolean);
  const variants = normalizeQuizVariants(safe.variants, widgets);
  const sample = materializeQuizQuestionVariant({
    id: String(safe.id || `question-${index + 1}`).trim() || `question-${index + 1}`,
    title: String(safe.title || `Question ${index + 1}`).trim() || `Question ${index + 1}`,
    modelId: String(safe.modelId || safe.model_id || "").trim(),
    widgets,
    variants
  }, 0);

  return {
    id: sample.id,
    title: sample.title,
    modelId: sample.modelId,
    timerSeconds,
    variantDrawMode,
    widgets,
    variants,
    variantCount: variants.length,
    answerWidgetCount: sample.answerWidgetCount,
    qcmWidgetCount: sample.qcmWidgetCount,
    selectionWidgetCount: sample.selectionWidgetCount,
    categoriesWidgetCount: sample.categoriesWidgetCount,
    doneWidgetCount: sample.doneWidgetCount,
    responseWidgetCount: sample.responseWidgetCount,
    responseType: sample.responseType,
    primaryAnswerWidgetId: sample.primaryAnswerWidgetId,
    primaryQcmWidgetId: sample.primaryQcmWidgetId,
    primarySelectionWidgetId: sample.primarySelectionWidgetId,
    primaryCategoriesWidgetId: sample.primaryCategoriesWidgetId,
    primaryDoneWidgetId: sample.primaryDoneWidgetId,
    primaryAnswerVisibleInQuestion: sample.primaryAnswerVisibleInQuestion,
    primaryQcmVisibleInQuestion: sample.primaryQcmVisibleInQuestion,
    primarySelectionVisibleInQuestion: sample.primarySelectionVisibleInQuestion,
    primaryCategoriesVisibleInQuestion: sample.primaryCategoriesVisibleInQuestion,
    primaryDoneVisibleInQuestion: sample.primaryDoneVisibleInQuestion,
    expectedAnswer: sample.expectedAnswer,
    expectedAnswerLabel: sample.expectedAnswerLabel
  };
}

export function normalizeQuizWidget(widget = {}, index = 0, sourceColumns = GRID_COLUMNS){
  const safe = widget && typeof widget === "object" && !Array.isArray(widget) ? widget : {};
  const type = String(safe.type || "text").trim().toLowerCase();
  if (!SUPPORTED_WIDGET_TYPES.has(type)) return null;
  const isMaskedText = type === "masked-text";
  const isFlashText = type === "flash-text";
  const isFlashImage = type === "flash-image";
  const isAnswer = type === "answer";
  const isVerifiedAnswer = type === "verified-answer";
  const isDone = type === "done";
  const isTextAnswer = isAnswer || isVerifiedAnswer;
  const isImage = type === "image" || isFlashImage;
  const isAudio = type === "audio";
  const isLabels = type === "labels";
  const isNumericKeypad = type === "numeric-keypad";
  const isQcmText = type === "qcm-text";
  const isSelectionWords = type === "selection-words";
  const isCategories = type === "categories";

  const questionText = isNumericKeypad || isDone || isImage || isAudio || isLabels || isCategories ? "" : String(safe.questionText ?? safe.question_text ?? "");
  const correctionText = isNumericKeypad || isDone || isImage || isAudio || isLabels || isCategories ? "" : String(safe.correctionText ?? safe.correction_text ?? questionText);
  const questionImageSource = isImage
    ? normalizeQuizImageSource(safe.questionImageSource ?? safe.question_image_source ?? safe.imageSource ?? safe.image_source)
    : null;
  const correctionImageSource = isImage
    ? normalizeQuizImageSource(safe.correctionImageSource ?? safe.correction_image_source ?? questionImageSource)
    : null;
  const questionAudioSource = isAudio
    ? normalizeQuizAudioSource(safe.questionAudioSource ?? safe.question_audio_source ?? safe.audioSource ?? safe.audio_source)
    : null;
  const correctionAudioSource = isAudio
    ? normalizeQuizAudioSource(safe.correctionAudioSource ?? safe.correction_audio_source ?? questionAudioSource)
    : null;
  const questionFormatting = normalizeFormattingRuns(safe.questionFormatting ?? safe.question_formatting, questionText.length);
  const correctionFormatting = normalizeFormattingRuns(safe.correctionFormatting ?? safe.correction_formatting, correctionText.length);
  const questionHtml = questionFormatting.length
    ? richTextModelToHtml(questionText, questionFormatting)
    : String(safe.questionHtml ?? safe.question_html ?? escapeHtml(questionText).replace(/\r?\n/g, "<br>"));
  const correctionHtml = correctionFormatting.length
    ? richTextModelToHtml(correctionText, correctionFormatting)
    : String(safe.correctionHtml ?? safe.correction_html ?? escapeHtml(correctionText).replace(/\r?\n/g, "<br>"));
  const sourceGridColumns = Math.max(1, Math.trunc(Number(sourceColumns) || GRID_COLUMNS));
  const questionArea = migrateHorizontalArea(
    safe.column,
    safe.columnSpan ?? safe.column_span,
    sourceGridColumns,
    isNumericKeypad ? GRID_COLUMNS : isCategories ? 8 : isQcmText || isSelectionWords ? 8 : isLabels ? 6 : isImage ? 4 : isAudio ? 4 : isMaskedText || isFlashText || isTextAnswer ? 8 : isDone ? 3 : 5
  );
  const correctionArea = migrateHorizontalArea(
    safe.correctionColumn ?? safe.correction_column ?? safe.column,
    safe.correctionColumnSpan ?? safe.correction_column_span ?? safe.columnSpan ?? safe.column_span,
    sourceGridColumns,
    questionArea.columnSpan
  );
  const column = questionArea.column;
  const row = clampInt(safe.row, 1, GRID_ROWS, 1);
  const columnSpan = questionArea.columnSpan;
  const rowSpan = clampInt(safe.rowSpan ?? safe.row_span, 1, GRID_ROWS, isCategories ? 4 : isLabels || isImage || isQcmText ? 3 : isSelectionWords || isAudio || isMaskedText || isFlashText ? 2 : 1);
  const overrides = normalizeCorrectionOverrides(safe.correctionOverrides || safe.correction_overrides || {});
  const questionVisible = isNumericKeypad || isDone
    ? true
    : safe.questionVisible ?? safe.question_visible ?? safe.visibility !== "correction";
  const correctionVisible = isNumericKeypad || isDone
    ? false
    : safe.correctionVisible ?? safe.correction_visible ?? safe.visibility !== "question";
  const inheritedCorrectionVisibility = questionVisible ? "visible" : "hidden";
  const correctionVisibility = isNumericKeypad || isDone
    ? "hidden"
    : normalizeCorrectionVisibility(
        safe.correctionVisibility ?? safe.correction_visibility,
        correctionVisible ? "visible" : "hidden"
      );
  if (!overrides.visibility && correctionVisibility !== inheritedCorrectionVisibility) {
    overrides.visibility = true;
  }

  return {
    id: String(safe.id || `widget-${index + 1}`).trim() || `widget-${index + 1}`,
    type,
    label: String(safe.label || (isMaskedText ? "Texte masqué" : isFlashText ? "Texte flash" : isFlashImage ? "Image flash" : isDone ? "J’ai terminé" : isVerifiedAnswer ? "Réponse texte vérifiée" : isAnswer ? "Réponse de l’élève" : isImage ? "Image" : isAudio ? "Audio" : isLabels ? "Étiquettes" : isNumericKeypad ? "Clavier numérique" : isQcmText ? "QCM (texte)" : isSelectionWords ? "Sélection de mots" : isCategories ? "Catégories" : "Texte")).trim(),
    questionText,
    correctionText,
    questionHtml,
    correctionHtml,
    questionFormatting,
    correctionFormatting,
    questionImageSource,
    correctionImageSource,
    questionAudioSource,
    correctionAudioSource,
    questionPlaceholder: String(safe.questionPlaceholder ?? safe.question_placeholder ?? ""),
    correctionPlaceholder: String(safe.correctionPlaceholder ?? safe.correction_placeholder ?? ""),
    column: clampInt(column, 1, GRID_COLUMNS - columnSpan + 1, 1),
    row: clampInt(row, 1, GRID_ROWS - rowSpan + 1, 1),
    columnSpan,
    rowSpan,
    correctionColumn: correctionArea.column,
    correctionRow: clampInt(safe.correctionRow ?? safe.correction_row, 1, GRID_ROWS, row),
    correctionColumnSpan: correctionArea.columnSpan,
    correctionRowSpan: clampInt(safe.correctionRowSpan ?? safe.correction_row_span, 1, GRID_ROWS, rowSpan),
    questionVisible: Boolean(questionVisible),
    correctionVisible: correctionVisibility !== "hidden",
    correctionVisibility,
    textAlign: normalizeTextAlign(safe.textAlign ?? safe.text_align),
    correctionTextAlign: normalizeTextAlign(safe.correctionTextAlign ?? safe.correction_text_align ?? safe.textAlign ?? safe.text_align),
    verticalAlign: normalizeVerticalAlign(safe.verticalAlign ?? safe.vertical_align),
    correctionVerticalAlign: normalizeVerticalAlign(safe.correctionVerticalAlign ?? safe.correction_vertical_align ?? safe.verticalAlign ?? safe.vertical_align),
    fontSize: normalizeQuizFontSize(safe.fontSize ?? safe.font_size),
    correctionFontSize: normalizeQuizFontSize(safe.correctionFontSize ?? safe.correction_font_size ?? safe.fontSize ?? safe.font_size),
    ...((isFlashText || isFlashImage) ? {
      flashDelaySeconds: normalizeFlashDelaySeconds(safe.flashDelaySeconds ?? safe.flash_delay_seconds),
      flashVisibleSeconds: normalizeFlashVisibleSeconds(safe.flashVisibleSeconds ?? safe.flash_visible_seconds)
    } : {}),
    qcmLayout: normalizeQcmLayout(safe.qcmLayout ?? safe.qcm_layout),
    qcmChoices: isQcmText
      ? normalizeQcmChoices(safe.qcmChoices ?? safe.qcm_choices ?? safe.choices, index)
      : [],
    labelItems: isLabels
      ? normalizeLabelItems(safe.labelItems ?? safe.label_items ?? safe.labels, index)
      : [],
    labelsSourceWidgetId: isCategories
      ? String(safe.labelsSourceWidgetId ?? safe.labels_source_widget_id ?? safe.sourceWidgetId ?? safe.source_widget_id ?? "").trim()
      : "",
    categoryItems: isCategories
      ? normalizeCategoryItems(safe.categoryItems ?? safe.category_items ?? safe.categories, index)
      : [],
    selectionExpectedTokenIndexes: isSelectionWords
      ? normalizeQuizSelectionIndexes(
          safe.selectionExpectedTokenIndexes ?? safe.selection_expected_token_indexes ?? safe.expectedTokenIndexes ?? safe.expected_token_indexes,
          getQuizSelectionWordCount(questionText)
        )
      : [],
    correctionOverrides: overrides
  };
}

function normalizeQcmLayout(value){
  const safe = String(value || "auto").trim().toLowerCase();
  return QCM_LAYOUTS.has(safe) ? safe : "auto";
}

function normalizeQcmChoices(sourceChoices, widgetIndex = 0){
  const source = Array.isArray(sourceChoices) ? sourceChoices.slice(0, QCM_MAX_CHOICES) : [];
  const choices = source.map((choice, index) => {
    const safe = choice && typeof choice === "object" && !Array.isArray(choice) ? choice : { text:choice };
    const text = String(safe.text ?? safe.label ?? "");
    return {
      id: String(safe.id || `qcm-${widgetIndex + 1}-choice-${index + 1}`).trim() || `qcm-${widgetIndex + 1}-choice-${index + 1}`,
      text,
      formatting: normalizeFormattingRuns(safe.formatting, text.length),
      isCorrect: Boolean(safe.isCorrect ?? safe.is_correct ?? index === 0)
    };
  });
  while (choices.length < QCM_MIN_CHOICES) {
    const index = choices.length;
    choices.push({
      id:`qcm-${widgetIndex + 1}-choice-${index + 1}`,
      text:"",
      formatting:[],
      isCorrect:index === 0
    });
  }
  let correctIndex = choices.findIndex((choice) => choice.isCorrect);
  if (correctIndex < 0) correctIndex = 0;
  choices.forEach((choice, index) => { choice.isCorrect = index === correctIndex; });
  return choices;
}

function captureVariantWidgetContent(widget){
  const content = {
    questionText: String(widget?.questionText ?? ""),
    questionFormatting: normalizeFormattingRuns(widget?.questionFormatting, String(widget?.questionText ?? "").length),
    correctionText: String(widget?.correctionText ?? widget?.questionText ?? ""),
    correctionFormatting: normalizeFormattingRuns(
      widget?.correctionFormatting,
      String(widget?.correctionText ?? widget?.questionText ?? "").length
    ),
    correctionTextOverridden: Boolean(widget?.correctionOverrides?.text),
    correctionFormattingOverridden: Boolean(widget?.correctionOverrides?.formatting)
  };
  if (widget?.type === "qcm-text") {
    content.qcmChoices = normalizeQcmChoices(widget.qcmChoices).map((choice) => ({ ...choice }));
  }
  if (widget?.type === "labels") {
    content.labelItems = normalizeLabelItems(widget.labelItems).map((item) => ({ ...item }));
  }
  if (widget?.type === "categories") {
    content.categoryItems = normalizeCategoryItems(widget.categoryItems).map((item) => ({ ...item, labelIds:[...item.labelIds] }));
  }
  if (widget?.type === "selection-words") {
    content.selectionExpectedTokenIndexes = normalizeQuizSelectionIndexes(
      widget.selectionExpectedTokenIndexes,
      getQuizSelectionWordCount(widget.questionText)
    );
  }
  if (widget?.type === "image" || widget?.type === "flash-image") {
    content.questionImageSource = normalizeQuizImageSource(widget.questionImageSource);
    content.correctionImageSource = normalizeQuizImageSource(widget.correctionImageSource ?? widget.questionImageSource);
    content.correctionImageOverridden = Boolean(widget.correctionOverrides?.image);
  }
  if (widget?.type === "audio") {
    content.questionAudioSource = normalizeQuizAudioSource(widget.questionAudioSource);
    content.correctionAudioSource = normalizeQuizAudioSource(widget.correctionAudioSource ?? widget.questionAudioSource);
    content.correctionAudioOverridden = Boolean(widget.correctionOverrides?.audio);
  }
  return content;
}

function normalizeVariantWidgetContent(source = {}, widget){
  const questionText = String(source.questionText ?? source.question_text ?? widget?.questionText ?? "");
  const correctionText = String(source.correctionText ?? source.correction_text ?? widget?.correctionText ?? questionText);
  return {
    questionText,
    questionFormatting: normalizeFormattingRuns(source.questionFormatting ?? source.question_formatting ?? widget?.questionFormatting, questionText.length),
    correctionText,
    correctionFormatting: normalizeFormattingRuns(
      source.correctionFormatting ?? source.correction_formatting ?? widget?.correctionFormatting,
      correctionText.length
    ),
    correctionTextOverridden: Boolean(
      source.correctionTextOverridden
      ?? source.correction_text_overridden
      ?? widget?.correctionOverrides?.text
    ),
    correctionFormattingOverridden: Boolean(
      source.correctionFormattingOverridden
      ?? source.correction_formatting_overridden
      ?? widget?.correctionOverrides?.formatting
    ),
    ...(widget?.type === "qcm-text" ? {
      qcmChoices: normalizeQcmChoices(source.qcmChoices ?? source.qcm_choices ?? widget.qcmChoices)
    } : {}),
    ...(widget?.type === "labels" ? {
      labelItems: normalizeLabelItems(source.labelItems ?? source.label_items ?? widget.labelItems)
    } : {}),
    ...(widget?.type === "categories" ? {
      categoryItems: normalizeCategoryItems(source.categoryItems ?? source.category_items ?? widget.categoryItems)
    } : {}),
    ...(widget?.type === "selection-words" ? {
      selectionExpectedTokenIndexes: normalizeQuizSelectionIndexes(
        source.selectionExpectedTokenIndexes ?? source.selection_expected_token_indexes ?? widget.selectionExpectedTokenIndexes,
        getQuizSelectionWordCount(questionText)
      )
    } : {}),
    ...((widget?.type === "image" || widget?.type === "flash-image") ? {
      questionImageSource: normalizeQuizImageSource(
        source.questionImageSource ?? source.question_image_source ?? widget.questionImageSource
      ),
      correctionImageSource: normalizeQuizImageSource(
        source.correctionImageSource ?? source.correction_image_source ?? widget.correctionImageSource ?? widget.questionImageSource
      ),
      correctionImageOverridden: Boolean(
        source.correctionImageOverridden
        ?? source.correction_image_overridden
        ?? widget.correctionOverrides?.image
      )
    } : {}),
    ...(widget?.type === "audio" ? {
      questionAudioSource: normalizeQuizAudioSource(
        source.questionAudioSource ?? source.question_audio_source ?? widget.questionAudioSource
      ),
      correctionAudioSource: normalizeQuizAudioSource(
        source.correctionAudioSource ?? source.correction_audio_source ?? widget.correctionAudioSource ?? widget.questionAudioSource
      ),
      correctionAudioOverridden: Boolean(
        source.correctionAudioOverridden
        ?? source.correction_audio_overridden
        ?? widget.correctionOverrides?.audio
      )
    } : {})
  };
}

function normalizeQuizVariants(sourceVariants, widgets = []){
  const rawVariants = Array.isArray(sourceVariants) && sourceVariants.length ? sourceVariants : [{}];
  return rawVariants.map((variant, index) => {
    const safe = variant && typeof variant === "object" && !Array.isArray(variant) ? variant : {};
    const sourceContents = safe.widgetContents && typeof safe.widgetContents === "object"
      ? safe.widgetContents
      : safe.widget_contents && typeof safe.widget_contents === "object"
        ? safe.widget_contents
        : {};
    const widgetContents = {};
    widgets.forEach((widget) => {
      widgetContents[widget.id] = normalizeVariantWidgetContent(
        sourceContents[widget.id] || captureVariantWidgetContent(widget),
        widget
      );
    });
    return {
      id: String(safe.id || `variant-${index + 1}`).trim() || `variant-${index + 1}`,
      widgetContents
    };
  });
}

function applyVariantContentToWidget(widget, content = {}){
  const normalized = normalizeVariantWidgetContent(content, widget);
  return {
    ...widget,
    questionText: normalized.questionText,
    questionFormatting: normalized.questionFormatting,
    questionHtml: richTextModelToHtml(normalized.questionText, normalized.questionFormatting),
    correctionText: normalized.correctionText,
    correctionFormatting: normalized.correctionFormatting,
    correctionHtml: richTextModelToHtml(normalized.correctionText, normalized.correctionFormatting),
    ...(widget.type === "qcm-text" ? { qcmChoices:normalized.qcmChoices } : {}),
    ...(widget.type === "labels" ? { labelItems:normalized.labelItems } : {}),
    ...(widget.type === "categories" ? { categoryItems:normalized.categoryItems } : {}),
    ...(widget.type === "selection-words" ? { selectionExpectedTokenIndexes:normalized.selectionExpectedTokenIndexes } : {}),
    ...((widget.type === "image" || widget.type === "flash-image") ? {
      questionImageSource: normalized.questionImageSource,
      correctionImageSource: normalized.correctionImageSource
    } : {}),
    ...(widget.type === "audio" ? {
      questionAudioSource: normalized.questionAudioSource,
      correctionAudioSource: normalized.correctionAudioSource
    } : {}),
    correctionOverrides: {
      ...(widget.correctionOverrides || {}),
      text: normalized.correctionTextOverridden,
      formatting: normalized.correctionFormattingOverridden,
      ...((widget.type === "image" || widget.type === "flash-image") ? { image:normalized.correctionImageOverridden } : {}),
      ...(widget.type === "audio" ? { audio:normalized.correctionAudioOverridden } : {})
    }
  };
}

export function materializeQuizQuestionVariant(question = {}, variantIndex = 0){
  const widgets = Array.isArray(question.widgets) ? question.widgets : [];
  const variants = Array.isArray(question.variants) && question.variants.length
    ? question.variants
    : normalizeQuizVariants([], widgets);
  const safeIndex = Math.min(variants.length - 1, Math.max(0, Math.trunc(Number(variantIndex) || 0)));
  const variant = variants[safeIndex] || variants[0];
  const materializedWidgets = widgets.map((widget) => applyVariantContentToWidget(
    widget,
    variant?.widgetContents?.[widget.id] || captureVariantWidgetContent(widget)
  ));
  const answerWidgets = materializedWidgets.filter((widget) => widget.type === "answer" || widget.type === "verified-answer");
  const qcmWidgets = materializedWidgets.filter((widget) => widget.type === "qcm-text");
  const selectionWidgets = materializedWidgets.filter((widget) => widget.type === "selection-words");
  const categoriesWidgets = materializedWidgets.filter((widget) => widget.type === "categories");
  const doneWidgets = materializedWidgets.filter((widget) => widget.type === "done");
  const primaryAnswerWidget = answerWidgets[0] || null;
  const primaryQcmWidget = qcmWidgets[0] || null;
  const primarySelectionWidget = selectionWidgets[0] || null;
  const primaryCategoriesWidget = categoriesWidgets[0] || null;
  const primaryDoneWidget = doneWidgets[0] || null;
  const correctionView = primaryAnswerWidget ? getWidgetView(primaryAnswerWidget, "correction") : null;
  const correctQcmChoice = primaryQcmWidget?.qcmChoices?.find((choice) => choice.isCorrect) || null;
  const selectionExpectedTokenIndexes = primarySelectionWidget
    ? normalizeQuizSelectionIndexes(
        primarySelectionWidget.selectionExpectedTokenIndexes,
        getQuizSelectionWordCount(primarySelectionWidget.questionText)
      )
    : [];
  const primaryLabelsWidget = primaryCategoriesWidget
    ? materializedWidgets.find((widget) => widget.type === "labels" && widget.id === primaryCategoriesWidget.labelsSourceWidgetId) || null
    : null;
  const categoryAssignmentState = primaryCategoriesWidget && primaryLabelsWidget
    ? getCategoryAssignments(primaryLabelsWidget.labelItems, primaryCategoriesWidget.categoryItems)
    : { assignments:{}, duplicates:new Set(), missing:[] };
  const expectedCategoryAssignments = categoryAssignmentState.assignments;
  return {
    ...question,
    widgets: materializedWidgets,
    activeVariantIndex: safeIndex,
    variantId: variant?.id || "",
    variantCount: variants.length,
    answerWidgetCount: answerWidgets.length,
    qcmWidgetCount: qcmWidgets.length,
    selectionWidgetCount: selectionWidgets.length,
    categoriesWidgetCount: categoriesWidgets.length,
    doneWidgetCount: doneWidgets.length,
    responseWidgetCount: answerWidgets.length + qcmWidgets.length + selectionWidgets.length + categoriesWidgets.length + doneWidgets.length,
    responseType: primaryDoneWidget ? "done" : primaryQcmWidget ? "qcm-text" : primarySelectionWidget ? "selection-words" : primaryCategoriesWidget ? "categories" : primaryAnswerWidget?.type === "verified-answer" ? "verified-answer" : primaryAnswerWidget ? "answer" : "",
    primaryAnswerWidgetId: primaryAnswerWidget?.id || "",
    primaryQcmWidgetId: primaryQcmWidget?.id || "",
    primarySelectionWidgetId: primarySelectionWidget?.id || "",
    primaryCategoriesWidgetId: primaryCategoriesWidget?.id || "",
    primaryDoneWidgetId: primaryDoneWidget?.id || "",
    primaryAnswerVisibleInQuestion: Boolean(primaryAnswerWidget && getWidgetView(primaryAnswerWidget, "question")?.visible),
    primaryQcmVisibleInQuestion: Boolean(primaryQcmWidget && getWidgetView(primaryQcmWidget, "question")?.visible),
    primarySelectionVisibleInQuestion: Boolean(primarySelectionWidget && getWidgetView(primarySelectionWidget, "question")?.visible),
    primaryCategoriesVisibleInQuestion: Boolean(primaryCategoriesWidget && getWidgetView(primaryCategoriesWidget, "question")?.visible),
    primaryDoneVisibleInQuestion: Boolean(primaryDoneWidget && getWidgetView(primaryDoneWidget, "question")?.visible),
    expectedAnswer: primaryDoneWidget
      ? ""
      : primaryQcmWidget
      ? String(correctQcmChoice?.id || "")
      : primarySelectionWidget
        ? selectionExpectedTokenIndexes.join(",")
        : primaryCategoriesWidget
          ? serializeCategoryAnswerMap(expectedCategoryAssignments)
        : String(correctionView?.text || "").trim(),
    expectedAnswerLabel: primaryQcmWidget
      ? String(correctQcmChoice?.text || "").trim()
      : primarySelectionWidget
        ? formatQuizSelectionIndexes(primarySelectionWidget.questionText, selectionExpectedTokenIndexes)
        : primaryCategoriesWidget
          ? "Classement attendu"
        : String(correctionView?.text || "").trim(),
    expectedTokenIndexes: selectionExpectedTokenIndexes,
    expectedCategoryAssignments,
    categoryAssignmentValid:Boolean(primaryCategoriesWidget && primaryLabelsWidget && primaryCategoriesWidget.categoryItems.length >= 2 && !categoryAssignmentState.missing.length && categoryAssignmentState.duplicates.size === 0)
  };
}

export function getWidgetView(widget, mode = "question"){
  if (!widget) return null;
  const visibilityState = getWidgetVisibilityState(widget, mode);
  if (widget.type === "done") {
    return normalizeViewBounds({
      html:"",
      text:"",
      formatting:[],
      placeholder:"",
      column:widget.column,
      row:widget.row,
      columnSpan:widget.columnSpan,
      rowSpan:widget.rowSpan,
      textAlign:"center",
      verticalAlign:"middle",
      fontSize:widget.fontSize,
      visible:mode !== "correction",
      visibilityMode:mode !== "correction" ? "visible" : "hidden"
    });
  }
  if (widget.type === "numeric-keypad") {
    return normalizeViewBounds({
      html: "",
      text: "",
      formatting: [],
      placeholder: "",
      column: widget.column,
      row: widget.row,
      columnSpan: widget.columnSpan,
      rowSpan: widget.rowSpan,
      textAlign: "center",
      verticalAlign: "middle",
      ...visibilityState
    });
  }
  if (widget.type === "labels") {
    const correctionMode = mode === "correction";
    const overrides = widget.correctionOverrides || {};
    return normalizeViewBounds({
      html:"",
      text:"",
      formatting:[],
      placeholder:"",
      labelItems:normalizeLabelItems(widget.labelItems),
      column:correctionMode && overrides.position ? widget.correctionColumn : widget.column,
      row:correctionMode && overrides.position ? widget.correctionRow : widget.row,
      columnSpan:correctionMode && overrides.size ? widget.correctionColumnSpan : widget.columnSpan,
      rowSpan:correctionMode && overrides.size ? widget.correctionRowSpan : widget.rowSpan,
      textAlign:"center",
      verticalAlign:"middle",
      ...visibilityState
    });
  }
  if (widget.type === "categories") {
    const correctionMode = mode === "correction";
    const overrides = widget.correctionOverrides || {};
    return normalizeViewBounds({
      html:"",
      text:"",
      formatting:[],
      placeholder:"",
      labelsSourceWidgetId:String(widget.labelsSourceWidgetId || ""),
      categoryItems:normalizeCategoryItems(widget.categoryItems),
      column:correctionMode && overrides.position ? widget.correctionColumn : widget.column,
      row:correctionMode && overrides.position ? widget.correctionRow : widget.row,
      columnSpan:correctionMode && overrides.size ? widget.correctionColumnSpan : widget.columnSpan,
      rowSpan:correctionMode && overrides.size ? widget.correctionRowSpan : widget.rowSpan,
      textAlign:"center",
      verticalAlign:"middle",
      ...visibilityState
    });
  }
  if (widget.type === "image" || widget.type === "flash-image") {
    const correctionMode = mode === "correction";
    const overrides = widget.correctionOverrides || {};
    return normalizeViewBounds({
      html:"",
      text:"",
      formatting:[],
      placeholder:"",
      imageSource:correctionMode && overrides.image ? widget.correctionImageSource : widget.questionImageSource,
      column:correctionMode && overrides.position ? widget.correctionColumn : widget.column,
      row:correctionMode && overrides.position ? widget.correctionRow : widget.row,
      columnSpan:correctionMode && overrides.size ? widget.correctionColumnSpan : widget.columnSpan,
      rowSpan:correctionMode && overrides.size ? widget.correctionRowSpan : widget.rowSpan,
      textAlign:"center",
      verticalAlign:"middle",
      ...visibilityState
    });
  }
  if (widget.type === "audio") {
    const correctionMode = mode === "correction";
    const overrides = widget.correctionOverrides || {};
    return normalizeViewBounds({
      html:"",
      text:"",
      formatting:[],
      placeholder:"",
      audioSource:correctionMode && overrides.audio ? widget.correctionAudioSource : widget.questionAudioSource,
      column:correctionMode && overrides.position ? widget.correctionColumn : widget.column,
      row:correctionMode && overrides.position ? widget.correctionRow : widget.row,
      columnSpan:correctionMode && overrides.size ? widget.correctionColumnSpan : widget.columnSpan,
      rowSpan:correctionMode && overrides.size ? widget.correctionRowSpan : widget.rowSpan,
      textAlign:"center",
      verticalAlign:"middle",
      ...visibilityState
    });
  }
  if (widget.type === "selection-words") {
    const correctionMode = mode === "correction";
    const overrides = widget.correctionOverrides || {};
    return normalizeViewBounds({
      html:richTextModelToHtml(widget.questionText, widget.questionFormatting),
      text:widget.questionText,
      formatting:widget.questionFormatting,
      placeholder:widget.questionPlaceholder,
      selectionExpectedTokenIndexes:normalizeQuizSelectionIndexes(
        widget.selectionExpectedTokenIndexes,
        getQuizSelectionWordCount(widget.questionText)
      ),
      column:correctionMode && overrides.position ? widget.correctionColumn : widget.column,
      row:correctionMode && overrides.position ? widget.correctionRow : widget.row,
      columnSpan:correctionMode && overrides.size ? widget.correctionColumnSpan : widget.columnSpan,
      rowSpan:correctionMode && overrides.size ? widget.correctionRowSpan : widget.rowSpan,
      textAlign:correctionMode && overrides.textAlign ? widget.correctionTextAlign : widget.textAlign,
      verticalAlign:correctionMode && overrides.verticalAlign ? widget.correctionVerticalAlign : widget.verticalAlign,
      fontSize:correctionMode && overrides.fontSize ? widget.correctionFontSize : widget.fontSize,
      ...visibilityState
    });
  }
  if (widget.type === "qcm-text") {
    const correctionMode = mode === "correction";
    const overrides = widget.correctionOverrides || {};
    return normalizeViewBounds({
      html:"",
      text:"",
      formatting:[],
      placeholder:"",
      qcmChoices:normalizeQcmChoices(widget.qcmChoices),
      qcmLayout:normalizeQcmLayout(widget.qcmLayout),
      column:correctionMode && overrides.position ? widget.correctionColumn : widget.column,
      row:correctionMode && overrides.position ? widget.correctionRow : widget.row,
      columnSpan:correctionMode && overrides.size ? widget.correctionColumnSpan : widget.columnSpan,
      rowSpan:correctionMode && overrides.size ? widget.correctionRowSpan : widget.rowSpan,
      textAlign:correctionMode && overrides.textAlign ? widget.correctionTextAlign : widget.textAlign,
      verticalAlign:correctionMode && overrides.verticalAlign ? widget.correctionVerticalAlign : widget.verticalAlign,
      fontSize:correctionMode && overrides.fontSize ? widget.correctionFontSize : widget.fontSize,
      ...visibilityState
    });
  }
  if (mode !== "correction") {
    return normalizeViewBounds({
      html: richTextModelToHtml(widget.questionText, widget.questionFormatting),
      text: widget.questionText,
      formatting: widget.questionFormatting,
      placeholder: widget.questionPlaceholder,
      column: widget.column,
      row: widget.row,
      columnSpan: widget.columnSpan,
      rowSpan: widget.rowSpan,
      textAlign: widget.textAlign,
      verticalAlign: widget.verticalAlign,
      fontSize: widget.fontSize,
      ...visibilityState
    });
  }

  const overrides = widget.correctionOverrides || {};
  const text = overrides.text ? widget.correctionText : widget.questionText;
  const formatting = overrides.formatting ? widget.correctionFormatting : widget.questionFormatting;
  return normalizeViewBounds({
    html: richTextModelToHtml(text, formatting),
    text,
    formatting,
    placeholder: widget.correctionPlaceholder,
    column: overrides.position ? widget.correctionColumn : widget.column,
    row: overrides.position ? widget.correctionRow : widget.row,
    columnSpan: overrides.size ? widget.correctionColumnSpan : widget.columnSpan,
    rowSpan: overrides.size ? widget.correctionRowSpan : widget.rowSpan,
    textAlign: overrides.textAlign ? widget.correctionTextAlign : widget.textAlign,
    verticalAlign: overrides.verticalAlign ? widget.correctionVerticalAlign : widget.verticalAlign,
    fontSize: overrides.fontSize ? widget.correctionFontSize : widget.fontSize,
    ...visibilityState
  });
}


export function normalizeQuestionSelection(selection = {}){
  return normalizeCommonQuestionSelection(selection);
}

export function getQuizQuestionSelectionKey(question = {}, index = 0){
  return getItemSelectionKey(question, index);
}

export function filterQuizQuestionsBySelection(questions = [], selection = {}){
  const normalizedQuestions = (Array.isArray(questions) ? questions : [])
    .map(normalizeQuizQuestion)
    .filter((question) => question.widgets.length > 0);
  return filterItemsByQuestionSelection(normalizedQuestions, selection, {
    itemKeyGetter: getQuizQuestionSelectionKey
  });
}

// Chaque variante est une unité sélectionnable et tirable par l’activité. Cela
// vaut autant pour les séries que pour les quiz composés dans l’Atelier : une
// question peut elle aussi posséder plusieurs variantes.
export function getQuizSelectionItems(snapshot = {}){
  const normalizedSnapshot = normalizeQuizSnapshot(snapshot);
  const questions = normalizedSnapshot.questions;
  return questions.flatMap((question) => {
    const variants = Array.isArray(question.variants) && question.variants.length
      ? question.variants
      : normalizeQuizVariants([], question.widgets);
    const sourceQuestionKey = getQuizQuestionSelectionKey(question);
    return variants.map((variant, variantIndex) => ({
      ...question,
      // Une seule variante est conservée afin que le runtime ne refasse pas
      // un tirage aléatoire parmi les variantes de cette question.
      variants:[variant],
      variantCount:1,
      selectionKey:`variant:${question.id}:${variant.id || variantIndex}`,
      sourceQuestionKey,
      sourceQuestionId:question.id,
      sourceVariantIndex:variantIndex,
      sourceVariantId:String(variant.id || "")
    }));
  });
}

export function normalizeQuizSelectionForSnapshot(snapshot = {}, selection = {}){
  const normalizedSelection = normalizeQuestionSelection(selection);
  if (normalizedSelection.mode !== "custom") return normalizedSelection;

  const selectedKeys = new Set(normalizedSelection.questionKeys);
  const items = getQuizSelectionItems(snapshot);
  const itemKeys = new Set(items.map((item, index) => getQuizQuestionSelectionKey(item, index)));
  const sourceQuestionKeys = new Set(items.map((item) => String(item.sourceQuestionKey || "")).filter(Boolean));
  const expandedKeys = [];

  // Compatibilité : les anciennes missions mémorisaient parfois la clé de la
  // question conteneur. Elle continue de signifier « toutes ses variantes ».
  items.forEach((item, index) => {
    const key = getQuizQuestionSelectionKey(item, index);
    if (selectedKeys.has(key) || selectedKeys.has(item.sourceQuestionKey)) expandedKeys.push(key);
  });

  // Ne jetons pas silencieusement les variantes/questions supprimées depuis la
  // création de la mission : l’éditeur de mission pourra ainsi les signaler.
  normalizedSelection.questionKeys.forEach((key) => {
    if (itemKeys.has(key) || sourceQuestionKeys.has(key)) return;
    if (!expandedKeys.includes(key)) expandedKeys.push(key);
  });

  return { ...normalizedSelection, questionKeys:expandedKeys };
}

export function filterQuizSnapshotBySelection(snapshot = {}, selection = {}){
  const items = getQuizSelectionItems(snapshot);
  const normalizedSelection = normalizeQuizSelectionForSnapshot(snapshot, selection);
  return filterItemsByQuestionSelection(items, normalizedSelection, {
    itemKeyGetter:getQuizQuestionSelectionKey
  });
}

export function getQuizSelectionItemCount(snapshot = {}){
  const normalizedSnapshot = normalizeQuizSnapshot(snapshot);
  const questions = normalizedSnapshot.questions;
  return questions.reduce((total, question) => {
    const count = Array.isArray(question?.variants) && question.variants.length
      ? question.variants.length
      : 1;
    return total + count;
  }, 0);
}

export function getQuestionSelectionSignature(selection = {}){
  return getCommonQuestionSelectionSignature(selection);
}

export function createQuestionDeck(questions = [], drawMode = DEFAULT_DRAW_MODE){
  const source = Array.isArray(questions) ? questions.map((question) => ({ ...question })) : [];
  if (!source.length) return [];

  // Les unités jouées sont les variantes sélectionnées, mais l’ordre de
  // passation a deux étages distincts : la mission ordonne les QUESTIONS, puis
  // chaque question décide elle-même de l’ordre de SES VARIANTES.
  const groups = [];
  const groupByQuestion = new Map();
  source.forEach((item, index) => {
    const groupKey = String(item?.sourceQuestionId || item?.id || `question-${index + 1}`);
    let group = groupByQuestion.get(groupKey);
    if (!group) {
      group = {
        key:groupKey,
        variantDrawMode:DRAW_MODES.has(String(item?.variantDrawMode || "").trim())
          ? String(item.variantDrawMode).trim()
          : DEFAULT_VARIANT_DRAW_MODE,
        items:[]
      };
      groupByQuestion.set(groupKey, group);
      groups.push(group);
    }
    group.items.push(item);
  });

  if (drawMode === "random") shuffleInPlace(groups);

  return groups.flatMap((group) => {
    const variants = group.items.slice().sort((left, right) =>
      Number(left?.sourceVariantIndex ?? 0) - Number(right?.sourceVariantIndex ?? 0)
    );
    if (group.variantDrawMode === "random") shuffleInPlace(variants);
    return variants;
  });
}

function shuffleInPlace(items = []){
  for (let index = items.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [items[index], items[swapIndex]] = [items[swapIndex], items[index]];
  }
  return items;
}

export function evaluateAnswer(question, rawAnswer = ""){
  if (question?.responseType === "done") {
    return {
      submittedAnswer:"",
      expectedAnswer:"",
      comparisonMode:"none",
      isCorrect:null,
      completed:true
    };
  }
  if (question?.responseType === "categories") {
    const expected = normalizeCategoryAnswerMap(question?.expectedCategoryAssignments ?? question?.expectedAnswer);
    const submitted = normalizeCategoryAnswerMap(rawAnswer);
    const expectedEntries = Object.entries(expected);
    const submittedEntries = Object.entries(submitted);
    const isCorrect = expectedEntries.length > 0
      && submittedEntries.length === expectedEntries.length
      && expectedEntries.every(([labelId, categoryId]) => submitted[labelId] === categoryId);
    return {
      submittedAnswer:serializeCategoryAnswerMap(submitted),
      submittedCategoryAssignments:submitted,
      expectedCategoryAssignments:expected,
      expectedAnswer:"Classement attendu",
      isCorrect
    };
  }
  if (question?.responseType === "selection-words") {
    const expectedIndexes = normalizeQuizSelectionIndexes(question?.expectedTokenIndexes ?? question?.expectedAnswer, Infinity);
    const submittedIndexes = normalizeQuizSelectionIndexes(rawAnswer, Infinity);
    const isCorrect = expectedIndexes.length > 0
      && submittedIndexes.length === expectedIndexes.length
      && submittedIndexes.every((value, index) => value === expectedIndexes[index]);
    return {
      submittedAnswer:submittedIndexes.join(","),
      submittedTokenIndexes:submittedIndexes,
      expectedTokenIndexes:expectedIndexes,
      expectedAnswer:String(question?.expectedAnswerLabel || "").trim(),
      isCorrect
    };
  }
  if (question?.responseType === "verified-answer") {
    const submittedAnswer = normalizeVerifiedTextAnswer(rawAnswer);
    const expectedAnswer = normalizeVerifiedTextAnswer(question?.expectedAnswer || "");
    return {
      submittedAnswer,
      expectedAnswer: String(question?.expectedAnswerLabel || question?.expectedAnswer || "").trim(),
      comparisonMode:"verified",
      isCorrect:Boolean(submittedAnswer) && Boolean(expectedAnswer) && submittedAnswer === expectedAnswer
    };
  }

  const submittedAnswer = normalizeSubmittedAnswer(rawAnswer);
  const expectedAnswer = normalizeSubmittedAnswer(question?.expectedAnswer || "");
  return {
    submittedAnswer,
    expectedAnswer: String(question?.expectedAnswerLabel || question?.expectedAnswer || "").trim(),
    comparisonMode:"standard",
    isCorrect: Boolean(submittedAnswer) && Boolean(expectedAnswer) && submittedAnswer === expectedAnswer
  };
}

export function normalizeSubmittedAnswer(value = ""){
  return String(value ?? "").replace(/\s+/gu, " ").trim();
}

export function normalizeVerifiedTextAnswer(value = ""){
  return String(value ?? "")
    .normalize("NFC")
    .replace(/[\u00a0\u202f]/gu, " ")
    .replace(/[’‘‛`´]/gu, "'")
    .replace(/\s+/gu, " ")
    .trim()
    // Les élèves ne sont pas évalués sur les conventions d'espacement typographique.
    // On neutralise donc tout espace placé immédiatement avant ou après un signe
    // de ponctuation, sans modifier le signe lui-même ni la casse ni l'orthographe.
    .replace(/\s*([\p{P}])\s*/gu, "$1");
}

export function getQuizTestIssues(snapshot = {}){
  const quiz = normalizeQuizSnapshot(snapshot);
  const issues = [];
  if (!quiz.questions.length) issues.push("Ajoutez au moins une question.");
  quiz.questions.forEach((question, index) => {
    const variants = Array.from({ length: Math.max(1, question.variants?.length || 1) }, (_, variantIndex) => (
      materializeQuizQuestionVariant(question, variantIndex)
    ));
    variants.forEach((variant, variantIndex) => {
      const suffix = variants.length > 1 ? `, variante ${variantIndex + 1}` : "";
      if (variant.responseWidgetCount !== 1) {
        issues.push(`La question ${index + 1}${suffix} doit contenir exactement un widget de réponse (« Réponse de l’élève », « Réponse texte vérifiée », « J’ai terminé », « QCM », « Sélection de mots » ou « Catégories »).`);
      } else if ((variant.responseType === "answer" || variant.responseType === "verified-answer") && !variant.primaryAnswerVisibleInQuestion) {
        issues.push(`Affichez la zone « Réponse de l’élève » de la question ${index + 1}${suffix} dans la vue Question.`);
      } else if (variant.responseType === "qcm-text" && !variant.primaryQcmVisibleInQuestion) {
        issues.push(`Affichez le QCM de la question ${index + 1}${suffix} dans la vue Question.`);
      } else if (variant.responseType === "selection-words" && !variant.primarySelectionVisibleInQuestion) {
        issues.push(`Affichez la sélection de mots de la question ${index + 1}${suffix} dans la vue Question.`);
      } else if (variant.responseType === "categories" && !variant.primaryCategoriesVisibleInQuestion) {
        issues.push(`Affichez les catégories de la question ${index + 1}${suffix} dans la vue Question.`);
      } else if (variant.responseType === "done" && !variant.primaryDoneVisibleInQuestion) {
        issues.push(`Affichez le bouton « J’ai terminé » de la question ${index + 1}${suffix} dans la vue Question.`);
      } else if (variant.responseType === "categories" && !variant.categoryAssignmentValid) {
        issues.push(`Reliez le widget Catégories à des Étiquettes et classez toutes les étiquettes renseignées dans la question ${index + 1}${suffix}.`);
      } else if (variant.responseType === "qcm-text") {
        const qcm = variant.widgets.find((widget) => widget.type === "qcm-text");
        const filledChoices = (qcm?.qcmChoices || []).filter((choice) => String(choice.text || "").trim());
        if (filledChoices.length < QCM_MIN_CHOICES || !filledChoices.some((choice) => choice.isCorrect)) {
          issues.push(`Renseignez au moins une bonne réponse et un distracteur dans le QCM de la question ${index + 1}${suffix}.`);
        }
      } else if (variant.responseType === "selection-words" && !variant.expectedTokenIndexes?.length) {
        issues.push(`Sélectionnez au moins un mot attendu dans la correction de la question ${index + 1}${suffix}.`);
      } else if (variant.responseType !== "done" && !variant.expectedAnswer) {
        issues.push(`Renseignez la réponse attendue de la question ${index + 1}${suffix} dans la vue Correction.`);
      }
    });
  });
  return issues;
}

function normalizeCorrectionVisibility(value, fallback = "visible"){
  const safe = String(value || "").trim().toLowerCase();
  return CORRECTION_VISIBILITY_MODES.has(safe) ? safe : fallback;
}

function getWidgetVisibilityState(widget, mode = "question"){
  if (widget?.type === "numeric-keypad" || widget?.type === "done") {
    const visible = mode !== "correction";
    return { visible, visibilityMode:visible ? "visible" : "hidden" };
  }
  if (mode !== "correction") {
    const visible = widget?.questionVisible !== false;
    return { visible, visibilityMode:visible ? "visible" : "hidden" };
  }
  const inheritedMode = widget?.questionVisible !== false ? "visible" : "hidden";
  const overrides = widget?.correctionOverrides || {};
  const visibilityMode = overrides.visibility
    ? normalizeCorrectionVisibility(
        widget?.correctionVisibility,
        widget?.correctionVisible === false ? "hidden" : "visible"
      )
    : inheritedMode;
  return { visible:visibilityMode !== "hidden", visibilityMode };
}

function normalizeCorrectionOverrides(value = {}){
  const safe = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const legacyContent = Boolean(safe.content);
  return {
    text: Boolean(safe.text ?? legacyContent),
    formatting: Boolean(safe.formatting ?? legacyContent),
    position: Boolean(safe.position),
    size: Boolean(safe.size),
    textAlign: Boolean(safe.textAlign ?? safe.text_align),
    verticalAlign: Boolean(safe.verticalAlign ?? safe.vertical_align),
    fontSize: Boolean(safe.fontSize ?? safe.font_size),
    visibility: Boolean(safe.visibility),
    image: Boolean(safe.image),
    audio: Boolean(safe.audio)
  };
}

function normalizeViewBounds(view){
  const columnSpan = clampInt(view.columnSpan, 1, GRID_COLUMNS, 1);
  const rowSpan = clampInt(view.rowSpan, 1, GRID_ROWS, 1);
  return {
    ...view,
    columnSpan,
    rowSpan,
    column: clampInt(view.column, 1, GRID_COLUMNS - columnSpan + 1, 1),
    row: clampInt(view.row, 1, GRID_ROWS - rowSpan + 1, 1),
    textAlign: normalizeTextAlign(view.textAlign),
    verticalAlign: normalizeVerticalAlign(view.verticalAlign),
    fontSize: normalizeQuizFontSize(view.fontSize),
    visible: view.visible !== false
  };
}

function normalizeTextAlign(value){
  const safe = String(value || "center").trim().toLowerCase();
  return ["left", "center", "right"].includes(safe) ? safe : "center";
}

function normalizeVerticalAlign(value){
  const safe = String(value || "middle").trim().toLowerCase();
  return ["top", "middle", "bottom"].includes(safe) ? safe : "middle";
}

function normalizeQuizFontSize(value){
  const safe = String(value || "normal").trim().toLowerCase();
  return QUIZ_FONT_SIZES.has(safe) ? safe : "normal";
}

function normalizeFormattingRuns(runs, textLength){
  const colors = new Set(["#d32f2f", "#2e7d32", "#1565c0", "#d49a00"]);
  const normalized = (Array.isArray(runs) ? runs : [])
    .map((run) => ({
      start: clampInt(run?.start, 0, textLength, 0),
      end: clampInt(run?.end, 0, textLength, 0),
      bold: Boolean(run?.bold),
      italic: Boolean(run?.italic),
      underline: Boolean(run?.underline),
      color: colors.has(String(run?.color || "").trim().toLowerCase())
        ? String(run.color).trim().toLowerCase()
        : ""
    }))
    .filter((run) => run.end > run.start)
    .sort((first, second) => first.start - second.start || first.end - second.end);
  return normalized;
}

function richTextModelToHtml(text, formatting = []){
  const rawText = String(text ?? "");
  const runs = normalizeFormattingRuns(formatting, rawText.length);
  if (!runs.length) return escapeHtml(rawText).replace(/\r?\n/g, "<br>");
  let cursor = 0;
  const chunks = [];
  const append = (value, run = null) => {
    if (!value) return;
    const escaped = escapeHtml(value).replace(/\r?\n/g, "<br>");
    if (!run || (!run.bold && !run.italic && !run.underline && !run.color)) {
      chunks.push(escaped);
      return;
    }
    const styles = [];
    if (run.bold) styles.push("font-weight:bold");
    if (run.italic) styles.push("font-style:italic");
    if (run.underline) styles.push("text-decoration:underline");
    if (run.color) styles.push(`color:${run.color}`);
    chunks.push(`<span style="${styles.join(";")}">${escaped}</span>`);
  };
  runs.forEach((run) => {
    if (run.start > cursor) append(rawText.slice(cursor, run.start));
    append(rawText.slice(run.start, run.end), run);
    cursor = Math.max(cursor, run.end);
  });
  if (cursor < rawText.length) append(rawText.slice(cursor));
  return chunks.join("");
}

function migrateHorizontalArea(column, columnSpan, sourceColumns = GRID_COLUMNS, fallbackSpan = 1){
  const fromColumns = Math.max(1, Math.trunc(Number(sourceColumns) || GRID_COLUMNS));
  const safeColumn = clampInt(column, 1, fromColumns, 1);
  const safeSpan = clampInt(columnSpan, 1, fromColumns - safeColumn + 1, fallbackSpan);
  if (fromColumns === GRID_COLUMNS) return { column: safeColumn, columnSpan: safeSpan };

  const start = Math.round(((safeColumn - 1) / fromColumns) * GRID_COLUMNS);
  const end = Math.round(((safeColumn - 1 + safeSpan) / fromColumns) * GRID_COLUMNS);
  const migratedColumn = clampInt(start + 1, 1, GRID_COLUMNS, 1);
  const migratedSpan = clampInt(Math.max(1, end - start), 1, GRID_COLUMNS - migratedColumn + 1, 1);
  return { column: migratedColumn, columnSpan: migratedSpan };
}

function clampInt(value, min, max, fallback){
  const number = Number(value);
  const safe = Number.isFinite(number) ? Math.trunc(number) : fallback;
  return Math.min(max, Math.max(min, safe));
}

function escapeHtml(value){
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export { GRID_COLUMNS, GRID_ROWS, DEFAULT_DRAW_MODE, DEFAULT_QUESTION_SELECTION_MODE };
