import { supabase } from "../../shared/supabase-client.js";
import {
  cleanDisplayName,
  normalizeAccessCode,
  normalizeConfigName,
  normalizeFolderRecord,
  sortFoldersByMeta
} from "../../shared/api-common.js";
import {
  filterQuizSnapshotBySelection,
  normalizeQuizRuntimeSettings,
  normalizeQuizSnapshot
} from "../../tools/quiz/model.js";
import {
  applyCatalogVisibility,
  filterEffectivelyActivePedagogicalNodes,
  getCatalogActivities,
  getPedagogicalNodes,
  normalizeCatalogActivity,
  normalizePedagogicalNode,
  normalizeCatalogGradeLevel,
  PEDAGOGICAL_NODE_TYPES,
  sortCatalogActivities,
  sortPedagogicalNodes
} from "../../shared/catalogue.js";

export { normalizeAccessCode, normalizeConfigName };

export async function getCurrentUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  return data.user ?? null;
}

export async function signInUser(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });
  if (error) throw error;
  return data.user ?? null;
}

export async function signUpUser(email, password, metadata = {}) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: metadata && typeof metadata === "object" ? metadata : {}
    }
  });
  if (error) throw error;
  return data;
}

export async function accessCodeExists(accessCode) {
  const code = normalizeAccessCode(accessCode);
  if (!code) return false;

  const { data, error } = await supabase.rpc("access_code_exists", {
    p_access_code: code
  });

  if (error) throw error;
  return data === true;
}

export async function signOutUser() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session ?? null;
}

export async function getMyTeacherSpace() {
  const user = await getCurrentUser();
  if (!user) {
    throw new Error("Aucun utilisateur connecté.");
  }

  const { data, error } = await supabase
    .from("teacher_spaces")
    .select("id, owner_user_id, access_code, created_at, updated_at, last_opened_at")
    .eq("owner_user_id", user.id)
    .maybeSingle();

  if (error) throw error;
  return data ?? null;
}

export async function createMyTeacherSpace(accessCode) {
  const user = await getCurrentUser();
  if (!user) {
    throw new Error("Aucun utilisateur connecté.");
  }

  const code = normalizeAccessCode(accessCode);
  if (!code) {
    throw new Error("Code de connexion vide.");
  }

  const payload = {
    owner_user_id: user.id,
    access_code: code,
    updated_at: new Date().toISOString(),
    last_opened_at: new Date().toISOString()
  };

  const { data, error } = await supabase
    .from("teacher_spaces")
    .insert(payload)
    .select("id, owner_user_id, access_code, created_at, updated_at, last_opened_at")
    .single();

  if (error) throw error;
  return data;
}

export async function createOrGetMyTeacherSpace(accessCode) {
  const existing = await getMyTeacherSpace();
  if (existing) return existing;

  return await createMyTeacherSpace(accessCode);
}

export async function updateMyTeacherSpace(teacherSpaceId, updates = {}) {
  const payload = {
    updated_at: new Date().toISOString()
  };

  if ("access_code" in updates) {
    const code = normalizeAccessCode(updates.access_code);
    if (!code) {
      throw new Error("Code de connexion invalide.");
    }
    payload.access_code = code;
  }

  const { data, error } = await supabase
    .from("teacher_spaces")
    .update(payload)
    .eq("id", teacherSpaceId)
    .select("id, owner_user_id, access_code, created_at, updated_at, last_opened_at")
    .single();

  if (error) throw error;
  return data;
}

export async function markTeacherSpaceAsOpened(teacherSpaceId) {
  const now = new Date().toISOString();

  const { data, error } = await supabase
    .from("teacher_spaces")
    .update({
      last_opened_at: now
    })
    .eq("id", teacherSpaceId)
    .select("id, owner_user_id, access_code, created_at, updated_at, last_opened_at")
    .single();

  if (error) throw error;
  return data;
}

export async function getMyTeacherClasses(teacherSpaceId) {
  const { data, error } = await supabase
    .from("teacher_classes")
    .select("id, teacher_space_id, name, display_order, created_at, updated_at")
    .eq("teacher_space_id", teacherSpaceId)
    .order("display_order", { ascending: true })
    .order("name", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function createTeacherClass(teacherSpaceId, name) {
  const cleanedName = cleanDisplayName(name);
  if (!cleanedName) {
    throw new Error("Nom de classe vide.");
  }

  const existing = await getMyTeacherClasses(teacherSpaceId);
  const nextOrder = existing.length;

  const { data, error } = await supabase
    .from("teacher_classes")
    .insert({
      teacher_space_id: teacherSpaceId,
      name: cleanedName,
      display_order: nextOrder,
      updated_at: new Date().toISOString()
    })
    .select("id, teacher_space_id, name, display_order, created_at, updated_at")
    .single();

  if (error) throw error;
  return data;
}

export async function updateTeacherClass(teacherClassId, updates = {}) {
  const payload = {
    updated_at: new Date().toISOString()
  };

  if ("name" in updates) {
    const cleanedName = cleanDisplayName(updates.name);
    if (!cleanedName) {
      throw new Error("Nom de classe vide.");
    }
    payload.name = cleanedName;
  }

  if ("display_order" in updates) {
    payload.display_order = Number(updates.display_order) || 0;
  }

  const { data, error } = await supabase
    .from("teacher_classes")
    .update(payload)
    .eq("id", teacherClassId)
    .select("id, teacher_space_id, name, display_order, created_at, updated_at")
    .single();

  if (error) throw error;
  return data;
}

export async function deleteTeacherClass(teacherClassId) {
  const { error } = await supabase
    .from("teacher_classes")
    .delete()
    .eq("id", teacherClassId);

  if (error) throw error;
}

export async function listTeacherVocabularyWords(teacherSpaceId) {
  const { data, error } = await supabase
    .from("teacher_vocabulary_words")
    .select("id, teacher_space_id, word, word_normalized, dictionary_page, created_at, updated_at")
    .eq("teacher_space_id", teacherSpaceId)
    .order("word_normalized", { ascending: true })
    .order("word", { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function replaceTeacherVocabularyWords(teacherSpaceId, items = []) {
  const { error } = await supabase.rpc("replace_teacher_vocabulary_words", {
    p_teacher_space_id: teacherSpaceId,
    p_items: items
  });

  if (error) throw error;
  return await listTeacherVocabularyWords(teacherSpaceId);
}

export async function resetTeacherVocabularyWords(teacherSpaceId) {
  const { error } = await supabase.rpc("reset_teacher_vocabulary_words", {
    p_teacher_space_id: teacherSpaceId
  });

  if (error) throw error;
  return await listTeacherVocabularyWords(teacherSpaceId);
}

export async function listTeacherPhonologyPresets(teacherSpaceId, { toolKey = "encodage" } = {}) {
  const spaceId = Number(teacherSpaceId);
  if (!Number.isFinite(spaceId) || spaceId <= 0) return [];

  const { data, error } = await supabase
    .from("teacher_phonology_presets")
    .select("id, teacher_space_id, tool_key, name, graph_order, created_at, updated_at")
    .eq("teacher_space_id", spaceId)
    .eq("tool_key", String(toolKey || "encodage").trim().toLowerCase())
    .order("name", { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function upsertTeacherPhonologyPreset(teacherSpaceId, preset = {}, { toolKey = "encodage" } = {}) {
  const spaceId = Number(teacherSpaceId);
  if (!Number.isFinite(spaceId) || spaceId <= 0) {
    throw new Error("Espace enseignant invalide.");
  }

  const id = String(preset?.id || "").trim();
  const name = String(preset?.name || "").trim();
  const graphOrder = Array.isArray(preset?.graphOrder) ? preset.graphOrder : [];

  if (!id) {
    throw new Error("Identifiant de preset manquant.");
  }

  if (!name) {
    throw new Error("Nom de preset manquant.");
  }

  const now = new Date().toISOString();

  const { error } = await supabase
    .from("teacher_phonology_presets")
    .upsert({
      id,
      teacher_space_id: spaceId,
      tool_key: String(toolKey || "encodage").trim().toLowerCase(),
      name,
      graph_order: graphOrder,
      updated_at: now,
      created_at: now
    }, {
      onConflict: "id"
    });

  if (error) throw error;
  return await listTeacherPhonologyPresets(spaceId, { toolKey });
}

export async function deleteTeacherPhonologyPreset(teacherSpaceId, presetId, { toolKey = "encodage" } = {}) {
  const spaceId = Number(teacherSpaceId);
  if (!Number.isFinite(spaceId) || spaceId <= 0) {
    throw new Error("Espace enseignant invalide.");
  }

  const id = String(presetId || "").trim();
  if (!id) return await listTeacherPhonologyPresets(spaceId, { toolKey });

  const { error } = await supabase
    .from("teacher_phonology_presets")
    .delete()
    .eq("id", id)
    .eq("teacher_space_id", spaceId)
    .eq("tool_key", String(toolKey || "encodage").trim().toLowerCase());

  if (error) throw error;
  return await listTeacherPhonologyPresets(spaceId, { toolKey });
}

export async function listStudentsForClass(teacherClassId) {
  const { data, error } = await supabase
    .from("students")
    .select("id, teacher_class_id, first_name, grade_level, student_code, display_order, updated_at")
    .eq("teacher_class_id", teacherClassId)
    .order("display_order", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function listStudentStorageContainersForSpace(teacherSpaceId) {
  return await getMyTeacherClasses(teacherSpaceId);
}

export async function ensureDefaultStudentStorageContainerForSpace(teacherSpaceId) {
  const containers = await listStudentStorageContainersForSpace(teacherSpaceId);
  if (containers.length) {
    return containers[0];
  }

  return await createTeacherClass(teacherSpaceId, "Ma classe");
}

export async function listStudentsForTeacherSpace(teacherSpaceId) {
  const storageContainers = await listStudentStorageContainersForSpace(teacherSpaceId);
  if (!storageContainers.length) return [];

  const storageContainerIds = storageContainers.map((item) => item.id);

  const { data, error } = await supabase
    .from("students")
    .select("id, teacher_class_id, first_name, grade_level, student_code, display_order, updated_at")
    .in("teacher_class_id", storageContainerIds)
    .order("display_order", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function listStudentsForSpace(teacherSpaceId) {
  return await listStudentsForTeacherSpace(teacherSpaceId);
}

function chunkHistoryValues(values = [], size = 100) {
  const safeSize = Math.max(1, Math.trunc(Number(size) || 100));
  const chunks = [];
  for (let index = 0; index < values.length; index += safeSize) {
    chunks.push(values.slice(index, index + safeSize));
  }
  return chunks;
}

function resolveHistoryNodeBranch(nodeId, nodesById) {
  const branch = [];
  const visited = new Set();
  let current = nodesById.get(String(nodeId || "")) || null;

  while (current && !visited.has(String(current.id))) {
    visited.add(String(current.id));
    branch.unshift(current);
    current = current.parent_id ? (nodesById.get(String(current.parent_id)) || null) : null;
  }

  return branch;
}

/**
 * Historique enseignant d'un élève.
 * Les instantanés sont ceux sauvegardés au moment exact de l'exécution :
 * on ne reconstruit jamais une question à partir de la configuration actuelle.
 */
export async function listStudentActivityHistory(studentId, { limit = 250 } = {}) {
  const id = Number(studentId);
  if (!Number.isFinite(id) || id <= 0) {
    throw new Error("Élève invalide.");
  }

  const safeLimit = Math.max(1, Math.min(500, Math.trunc(Number(limit) || 250)));
  const { data: sessionsData, error: sessionsError } = await supabase
    .from("student_activity_sessions")
    .select([
      "id",
      "student_id",
      "catalog_activity_id",
      "context",
      "status",
      "tool_id",
      "tool_instance_id",
      "activity_title",
      "started_level",
      "ended_level",
      "questions_count",
      "correct_count",
      "wrong_count",
      "duration_ms",
      "played_at",
      "started_at",
      "ended_at",
      "metadata_json",
      "mission_id",
      "mission_step_id",
      "progress_voided_at",
      "history_hidden_at",
      "created_at"
    ].join(", "))
    .eq("student_id", id)
    .is("history_hidden_at", null)
    .order("started_at", { ascending: false })
    .limit(safeLimit);

  if (sessionsError) throw sessionsError;
  const sessions = Array.isArray(sessionsData) ? sessionsData : [];
  if (!sessions.length) return [];

  const sessionIds = sessions.map((row) => String(row.id || "")).filter(Boolean);
  const activityIds = [...new Set(sessions.map((row) => String(row.catalog_activity_id || "").trim()).filter(Boolean))];

  const questionRows = [];
  for (const ids of chunkHistoryValues(sessionIds, 100)) {
    const { data, error } = await supabase
      .from("student_activity_session_questions")
      .select([
        "id",
        "session_id",
        "question_index",
        "tool_id",
        "tool_instance_id",
        "level_presented",
        "level_after",
        "outcome",
        "is_correct",
        "points_awarded",
        "duration_ms",
        "question_snapshot",
        "answer_snapshot",
        "correction_snapshot",
        "answered_at",
        "created_at"
      ].join(", "))
      .in("session_id", ids)
      .order("question_index", { ascending: true });
    if (error) throw error;
    questionRows.push(...(Array.isArray(data) ? data : []));
  }

  const catalogRows = [];
  for (const ids of chunkHistoryValues(activityIds, 100)) {
    const { data, error } = await supabase
      .from("catalog_activities")
      .select("id, pedagogical_node_id, tool_id, title, description")
      .in("id", ids);
    if (error) throw error;
    catalogRows.push(...(Array.isArray(data) ? data : []));
  }

  let pedagogicalNodes = [];
  try {
    pedagogicalNodes = await queryPedagogicalNodes();
  } catch (error) {
    console.warn("Arborescence indisponible pour qualifier l’historique élève.", error);
    pedagogicalNodes = getPedagogicalNodes();
  }

  const nodesById = new Map(pedagogicalNodes.map((node) => [String(node.id), node]));
  const catalogById = new Map(catalogRows.map((row) => [String(row.id), row]));
  const questionsBySession = new Map();

  questionRows.forEach((row) => {
    const sessionId = String(row.session_id || "");
    if (!questionsBySession.has(sessionId)) questionsBySession.set(sessionId, []);
    questionsBySession.get(sessionId).push(row);
  });

  return sessions.map((session) => {
    const activityId = String(session.catalog_activity_id || "");
    const catalog = catalogById.get(activityId) || null;
    const branch = resolveHistoryNodeBranch(catalog?.pedagogical_node_id, nodesById);
    const discipline = branch.find((node) => node.node_type === "discipline") || null;
    const domain = branch.find((node) => node.node_type === "domain") || null;
    const questions = (questionsBySession.get(String(session.id)) || [])
      .sort((a, b) => Number(a.question_index) - Number(b.question_index));

    return {
      ...session,
      activity_title: String(session.activity_title || catalog?.title || activityId || "Activité").trim() || "Activité",
      tool_id: String(session.tool_id || catalog?.tool_id || "").trim(),
      pedagogical_node_id: String(catalog?.pedagogical_node_id || "").trim() || null,
      discipline_id: discipline ? String(discipline.id) : null,
      discipline_name: discipline ? String(discipline.name || "").trim() : "",
      domain_id: domain ? String(domain.id) : null,
      domain_name: domain ? String(domain.name || "").trim() : "",
      questions
    };
  });
}

function normalizeStudentAttemptActionArgs(attemptId, studentId) {
  const id = String(attemptId || "").trim();
  const sid = Number(studentId);
  if (!id) throw new Error("Tentative invalide.");
  if (!Number.isFinite(sid) || sid <= 0) throw new Error("Élève invalide.");
  return { id, sid };
}

/**
 * Retire seulement la trace de l’historique visible.
 * La ligne technique est conservée afin que la progression reste reconstructible.
 */
export async function deleteStudentActivityHistoryAttempt(attemptId, studentId) {
  const { id, sid } = normalizeStudentAttemptActionArgs(attemptId, studentId);
  const { data, error } = await supabase.rpc("hide_student_activity_attempt_as_teacher", {
    p_attempt_id: id,
    p_student_id: sid
  });
  if (error) throw error;
  if (data !== true) throw new Error("Cette tentative n’a pas pu être retirée de l’historique.");
  return true;
}

/**
 * Annule les effets pédagogiques d’une tentative sans supprimer sa trace.
 * Exploration : recalcule les statistiques et le niveau de l’activité.
 * Mission : remet l’étape ciblée et toutes les suivantes à faire.
 */
export async function resetStudentActivityAttemptEffects(attemptId, studentId) {
  const { id, sid } = normalizeStudentAttemptActionArgs(attemptId, studentId);
  const { data, error } = await supabase.rpc("reset_student_activity_attempt_as_teacher", {
    p_attempt_id: id,
    p_student_id: sid,
    p_delete_history: false
  });
  if (error) throw error;
  return Array.isArray(data) ? (data[0] || null) : data;
}

/**
 * Annule les effets pédagogiques puis efface physiquement la tentative ciblée.
 */
export async function deleteStudentActivityAttemptTotally(attemptId, studentId) {
  const { id, sid } = normalizeStudentAttemptActionArgs(attemptId, studentId);
  const { data, error } = await supabase.rpc("reset_student_activity_attempt_as_teacher", {
    p_attempt_id: id,
    p_student_id: sid,
    p_delete_history: true
  });
  if (error) throw error;
  return Array.isArray(data) ? (data[0] || null) : data;
}

export async function createStudent(teacherClassId, student = {}) {
  const firstName = String(student.first_name || "").trim();
  const gradeLevel = String(student.grade_level || "").trim() || null;

  if (!firstName) {
    throw new Error("Prénom vide.");
  }

  const existing = await listStudentsForClass(teacherClassId);
  const maxExistingOrder = existing.reduce((maxOrder, item) => {
    const value = Number(item?.display_order);
    return Number.isFinite(value) ? Math.max(maxOrder, value) : maxOrder;
  }, -1);
  const nextOrder = maxExistingOrder + 1;

  const { data, error } = await supabase
    .from("students")
    .insert({
      teacher_class_id: teacherClassId,
      first_name: firstName,
      grade_level: gradeLevel,
      student_code: normalizeStudentCode(student.student_code),
      display_order: nextOrder,
      updated_at: new Date().toISOString()
    })
    .select("id, teacher_class_id, first_name, grade_level, student_code, display_order, updated_at")
    .single();

  if (error) throw error;
  return data;
}

export async function createStudentForTeacherSpace(teacherSpaceId, student = {}) {
  const storageContainer = await ensureDefaultStudentStorageContainerForSpace(teacherSpaceId);
  return await createStudent(storageContainer.id, student);
}

export async function updateStudent(studentId, updates = {}) {
  const payload = {
    updated_at: new Date().toISOString()
  };

  if ("first_name" in updates) {
    const firstName = String(updates.first_name || "").trim();
    if (!firstName) {
      throw new Error("Prénom vide.");
    }
    payload.first_name = firstName;
  }

  if ("grade_level" in updates) {
    payload.grade_level = String(updates.grade_level || "").trim() || null;
  }

  if ("student_code" in updates) {
    payload.student_code = normalizeStudentCode(updates.student_code);
  }

  if ("display_order" in updates) {
    const displayOrder = Number(updates.display_order);
    if (!Number.isFinite(displayOrder)) {
      throw new Error("Ordre d’élève invalide.");
    }
    payload.display_order = Math.max(0, Math.trunc(displayOrder));
  }

  const { data, error } = await supabase
    .from("students")
    .update(payload)
    .eq("id", studentId)
    .select("id, teacher_class_id, first_name, grade_level, student_code, display_order, updated_at")
    .single();

  if (error) throw error;
  return data;
}

export async function deleteStudent(studentId) {
  const { error } = await supabase
    .from("students")
    .delete()
    .eq("id", studentId);

  if (error) throw error;
}

export async function saveStudentOrderForTeacherSpace(teacherSpaceId, orderedStudentIds = []) {
  if (!Array.isArray(orderedStudentIds)) {
    throw new Error("Ordre d’élèves invalide.");
  }

  const students = await listStudentsForTeacherSpace(teacherSpaceId);
  const currentIds = students.map((student) => String(student.id));
  const currentIdSet = new Set(currentIds);

  const seen = new Set();
  const normalizedOrderedIds = orderedStudentIds
    .map((id) => String(id))
    .filter((id) => currentIdSet.has(id))
    .filter((id) => {
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });

  const missingIds = currentIds.filter((id) => !seen.has(id));
  const finalIds = [...normalizedOrderedIds, ...missingIds];

  await Promise.all(finalIds.map((studentId, index) => updateStudent(studentId, { display_order: index })));

  return finalIds;
}

export async function replaceStudentsForClass(teacherClassId, students) {
  if (!Array.isArray(students)) {
    throw new Error("Liste élèves invalide.");
  }

  const { error: delError } = await supabase
    .from("students")
    .delete()
    .eq("teacher_class_id", teacherClassId);

  if (delError) throw delError;

  if (!students.length) return [];

  const seen = new Set();

  const normalizedStudents = students
    .map((s) => ({
      first_name: String(s.first_name || "").trim(),
      grade_level: String(s.grade_level || "").trim() || null
    }))
    .filter((s) => s.first_name)
    .filter((s) => {
      const key = s.first_name.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

  const payload = normalizedStudents.map((s, index) => ({
    teacher_class_id: teacherClassId,
    first_name: s.first_name,
    grade_level: s.grade_level,
    display_order: index,
    updated_at: new Date().toISOString()
  }));

  const { data, error } = await supabase
    .from("students")
    .insert(payload)
    .select();

  if (error) throw error;

  return data;
}

function normalizeStudentCode(value) {
  const safe = String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 3);
  return safe || null;
}

export function listPedagogicalNodes() {
  return getPedagogicalNodes();
}

async function queryPedagogicalNodes() {
  const pageSize = 1000;
  const rows = [];

  for (let from = 0; ; from += pageSize) {
    const { data, error } = await supabase
      .from("pedagogical_nodes")
      .select("id, parent_id, name, node_type, student_label, student_navigation_mode, display_order, is_active, created_at, updated_at")
      .order("parent_id", { ascending: true, nullsFirst: true })
      .order("display_order", { ascending: true })
      .order("name", { ascending: true })
      .order("id", { ascending: true })
      .range(from, from + pageSize - 1);
    if (error) throw error;

    const page = Array.isArray(data) ? data : [];
    rows.push(...page);
    if (page.length < pageSize) break;
  }

  return sortPedagogicalNodes(rows.map(normalizePedagogicalNode));
}

export async function listPedagogicalNodesForTeacher() {
  try {
    return filterEffectivelyActivePedagogicalNodes(await queryPedagogicalNodes());
  } catch (err) {
    console.warn("Arborescence pédagogique en base indisponible, utilisation du secours local.", err);
    return filterEffectivelyActivePedagogicalNodes(getPedagogicalNodes());
  }
}

export async function listPedagogicalNodesForAdmin() {
  const hideRuntimeNodes = (nodes) => (Array.isArray(nodes) ? nodes : [])
    .filter((node) => !String(node?.id || "").startsWith("system-runtime"));
  try {
    return hideRuntimeNodes(await queryPedagogicalNodes());
  } catch (err) {
    console.warn("Arborescence pédagogique Admin indisponible, utilisation du secours local.", err);
    return hideRuntimeNodes(getPedagogicalNodes());
  }
}

export async function createPedagogicalNodeAsAdmin(folder = {}) {
  const id = String(folder.id || "").trim().toLowerCase();
  const name = cleanDisplayName(folder.name);
  const parentId = String(folder.parent_id || "").trim() || null;
  const nodeType = String(folder.node_type || "").trim();
  if (!id || !/^[a-z0-9][a-z0-9._-]{0,159}$/.test(id)) throw new Error("Identifiant de nœud invalide.");
  if (!name) throw new Error("Nom du nœud vide.");
  if (!PEDAGOGICAL_NODE_TYPES.includes(nodeType)) throw new Error("Type de nœud invalide.");
  if (nodeType === "grade_level" && !normalizeCatalogGradeLevel(name)) {
    throw new Error("Un dossier de niveau doit être nommé CP, CE1, CE2, CM1 ou CM2.");
  }
  const payload = {
    id,
    parent_id: parentId,
    name,
    node_type: nodeType,
    student_label: nodeType === "grade_level" ? null : (cleanDisplayName(folder.student_label) || null),
    student_navigation_mode: nodeType === "grade_level"
      ? "folder"
      : (String(folder.student_navigation_mode || "").trim() === "transparent" ? "transparent" : "folder"),
    display_order: Math.max(0, Math.trunc(Number(folder.display_order) || 0)),
    is_active: folder.is_active !== false
  };
  const { data, error } = await supabase.from("pedagogical_nodes").insert(payload)
    .select("id, parent_id, name, node_type, student_label, student_navigation_mode, display_order, is_active, created_at, updated_at")
    .single();
  if (error) throw error;
  return normalizePedagogicalNode(data);
}

export async function updatePedagogicalNodeAsAdmin(folderId, updates = {}) {
  const id = String(folderId || "").trim().toLowerCase();
  if (!id) throw new Error("Nœud pédagogique introuvable.");
  const payload = {};
  if ("name" in updates) {
    payload.name = cleanDisplayName(updates.name);
    const currentNode = (await queryPedagogicalNodes()).find((node) => node.id === id) || null;
    if (currentNode?.node_type === "grade_level" && !normalizeCatalogGradeLevel(payload.name)) {
      throw new Error("Un dossier de niveau doit être nommé CP, CE1, CE2, CM1 ou CM2.");
    }
  }
  if ("student_label" in updates) payload.student_label = cleanDisplayName(updates.student_label) || null;
  if ("student_navigation_mode" in updates) {
    payload.student_navigation_mode = String(updates.student_navigation_mode || "").trim() === "transparent"
      ? "transparent"
      : "folder";
  }
  if ("parent_id" in updates) payload.parent_id = String(updates.parent_id || "").trim() || null;
  if ("display_order" in updates) payload.display_order = Math.max(0, Math.trunc(Number(updates.display_order) || 0));
  if ("is_active" in updates) payload.is_active = updates.is_active !== false;
  if (!Object.keys(payload).length) return null;
  const { data, error } = await supabase.from("pedagogical_nodes").update(payload).eq("id", id)
    .select("id, parent_id, name, node_type, student_label, student_navigation_mode, display_order, is_active, created_at, updated_at")
    .single();
  if (error) throw error;
  return normalizePedagogicalNode(data);
}

export async function deletePedagogicalNodeAsAdmin(folderId) {
  const id = String(folderId || "").trim().toLowerCase();
  if (!id) throw new Error("Nœud pédagogique introuvable.");
  const { error } = await supabase.from("pedagogical_nodes").delete().eq("id", id);
  if (error) throw error;
}

async function listPublishedCatalogActivities() {
  try {
    const { data, error } = await supabase
      .from("catalog_activities")
      .select("id, pedagogical_node_id, tool_id, title, description, adventure_tier, display_order, status, default_visible, levels_json, created_at, updated_at")
      .eq("status", "published")
      .order("pedagogical_node_id", { ascending: true })
      .order("adventure_tier", { ascending: true })
      .order("display_order", { ascending: true })
      .order("title", { ascending: true });

    if (error) throw error;
    return sortCatalogActivities((Array.isArray(data) ? data : []).map(normalizeCatalogActivity));
  } catch (err) {
    // Mode secours : utile hors Supabase ou avant application de la migration super-admin.
    console.warn("Catalogue système en base indisponible, utilisation du catalogue de secours.", err);
    return getCatalogActivities();
  }
}

export async function listCatalogActivitiesForTeacherSpace(teacherSpaceId) {
  const [catalogActivities, folders] = await Promise.all([
    listPublishedCatalogActivities(),
    listPedagogicalNodesForTeacher()
  ]);
  const activeFolderIds = new Set(folders.map((folder) => String(folder.id)));
  const availableActivities = catalogActivities.filter((activity) => activeFolderIds.has(String(activity.pedagogical_node_id || activity.folder_id || "")));
  const { data, error } = await supabase
    .from("catalog_activity_visibility")
    .select("catalog_activity_id, is_visible, updated_at")
    .eq("teacher_space_id", teacherSpaceId);

  if (error) throw error;
  return sortCatalogActivities(applyCatalogVisibility(availableActivities, Array.isArray(data) ? data : []));
}

export async function setCatalogActivityVisibility(teacherSpaceId, catalogActivityId, isVisible) {
  const payload = {
    teacher_space_id: teacherSpaceId,
    catalog_activity_id: String(catalogActivityId || "").trim(),
    is_visible: isVisible !== false,
    updated_at: new Date().toISOString()
  };

  if (!payload.teacher_space_id || !payload.catalog_activity_id) {
    throw new Error("Activité de catalogue introuvable.");
  }

  const { error } = await supabase
    .from("catalog_activity_visibility")
    .upsert(payload, { onConflict: "teacher_space_id,catalog_activity_id" });

  if (error) throw error;
  return await listCatalogActivitiesForTeacherSpace(teacherSpaceId);
}


/* =========================
   ACTIVITÉS PERSONNELLES
   ========================= */

const TEACHER_ACTIVITY_FOLDER_FIELDS = "id, teacher_space_id, parent_id, name, display_order, created_at, updated_at";
const TEACHER_ACTIVITY_FIELDS = "id, teacher_space_id, folder_id, title, title_normalized, activity_type, difficulty_mode, source_quiz_id, config_json, levels_json, display_order, created_at, updated_at";

export async function listTeacherActivityFoldersForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("teacher_activity_folders")
    .select(TEACHER_ACTIVITY_FOLDER_FIELDS)
    .eq("teacher_space_id", spaceId)
    .order("display_order", { ascending:true })
    .order("name", { ascending:true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createTeacherActivityFolderForSpace(teacherSpaceId, { name, parent_id = null } = {}) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const cleanName = cleanDisplayName(name);
  if (!cleanName) throw new Error("Nom de dossier vide.");
  const safeParentId = normalizeNullableUuid(parent_id);
  const folders = await listTeacherActivityFoldersForSpace(spaceId);
  const nextOrder = folders
    .filter((folder) => String(folder.parent_id || "") === String(safeParentId || ""))
    .reduce((max, folder) => Math.max(max, Number(folder.display_order) || 0), -1) + 1;
  const { data, error } = await supabase
    .from("teacher_activity_folders")
    .insert({
      teacher_space_id:spaceId,
      parent_id:safeParentId,
      name:cleanName,
      display_order:nextOrder
    })
    .select(TEACHER_ACTIVITY_FOLDER_FIELDS)
    .single();
  if (error) throw error;
  return data;
}

export async function updateTeacherActivityFolder(folderId, updates = {}) {
  const id = normalizeUuid(folderId);
  if (!id) throw new Error("Dossier d’activités invalide.");
  const payload = {};
  if ("name" in updates) {
    payload.name = cleanDisplayName(updates.name);
    if (!payload.name) throw new Error("Nom de dossier vide.");
  }
  if ("parent_id" in updates) payload.parent_id = normalizeNullableUuid(updates.parent_id);
  if ("display_order" in updates) payload.display_order = Math.max(0, Math.trunc(Number(updates.display_order) || 0));
  if (!Object.keys(payload).length) throw new Error("Aucune modification de dossier à enregistrer.");
  const { data, error } = await supabase
    .from("teacher_activity_folders")
    .update(payload)
    .eq("id", id)
    .select(TEACHER_ACTIVITY_FOLDER_FIELDS)
    .single();
  if (error) throw error;
  return data;
}

export async function deleteTeacherActivityFolder(folderId) {
  const id = normalizeUuid(folderId);
  if (!id) throw new Error("Dossier d’activités invalide.");
  const { error } = await supabase.from("teacher_activity_folders").delete().eq("id", id);
  if (error) throw error;
}

export async function listTeacherActivitiesForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("teacher_activities")
    .select(TEACHER_ACTIVITY_FIELDS)
    .eq("teacher_space_id", spaceId)
    .order("display_order", { ascending:true })
    .order("title", { ascending:true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function saveTeacherActivityForSpace(teacherSpaceId, activity = {}) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const title = cleanDisplayName(activity.title);
  if (!title) throw new Error("Titre d’activité vide.");
  const activityType = ["quiz", "series", "tool"].includes(String(activity.activity_type || "").trim())
    ? String(activity.activity_type || "").trim()
    : "quiz";
  const difficultyMode = String(activity.difficulty_mode || "single").trim() === "adaptive" ? "adaptive" : "single";
  const sourceQuizId = normalizeNullableUuid(activity.source_quiz_id);
  if (["quiz", "series"].includes(activityType) && !sourceQuizId) {
    throw new Error("Quiz source introuvable pour cette activité.");
  }
  const payload = {
    teacher_space_id:spaceId,
    folder_id:normalizeNullableUuid(activity.folder_id),
    title,
    title_normalized:normalizeConfigName(title),
    activity_type:activityType,
    difficulty_mode:difficultyMode,
    source_quiz_id:sourceQuizId,
    config_json:activity.config_json && typeof activity.config_json === "object" && !Array.isArray(activity.config_json)
      ? cloneJsonValue(activity.config_json)
      : {},
    levels_json:activity.levels_json && typeof activity.levels_json === "object" && !Array.isArray(activity.levels_json)
      ? cloneJsonValue(activity.levels_json)
      : {},
    display_order:Math.max(0, Math.trunc(Number(activity.display_order) || 0))
  };

  const existingId = normalizeUuid(activity.id);
  let query;
  if (existingId) {
    query = supabase
      .from("teacher_activities")
      .update(payload)
      .eq("id", existingId)
      .eq("teacher_space_id", spaceId);
  } else {
    const existing = await listTeacherActivitiesForSpace(spaceId);
    payload.display_order = existing
      .filter((item) => String(item.folder_id || "") === String(payload.folder_id || ""))
      .reduce((max, item) => Math.max(max, Number(item.display_order) || 0), -1) + 1;
    query = supabase.from("teacher_activities").insert(payload);
  }

  const { data, error } = await query.select(TEACHER_ACTIVITY_FIELDS).single();
  if (error) throw error;
  return data;
}

export async function updateTeacherActivityPlacement(activityId, updates = {}) {
  const id = normalizeUuid(activityId);
  if (!id) throw new Error("Activité invalide.");
  const payload = {};
  if ("folder_id" in updates) payload.folder_id = normalizeNullableUuid(updates.folder_id);
  if ("display_order" in updates) payload.display_order = Math.max(0, Math.trunc(Number(updates.display_order) || 0));
  if (!Object.keys(payload).length) throw new Error("Aucun déplacement d’activité à enregistrer.");
  const { data, error } = await supabase
    .from("teacher_activities")
    .update(payload)
    .eq("id", id)
    .select(TEACHER_ACTIVITY_FIELDS)
    .single();
  if (error) throw error;
  return data;
}

export async function deleteTeacherActivity(activityId) {
  const id = normalizeUuid(activityId);
  if (!id) throw new Error("Activité invalide.");
  const { error } = await supabase.from("teacher_activities").delete().eq("id", id);
  if (error) throw error;
}


/* =========================
   SÉQUENCES D’ACTIVITÉS
   ========================= */

const TEACHER_SEQUENCE_FIELDS = "id, teacher_space_id, title, title_normalized, created_at, updated_at";
const TEACHER_SEQUENCE_ITEM_FIELDS = "id, sequence_id, position, source_type, source_id, title_snapshot, difficulty_mode, difficulty_level, execution_limit_mode, execution_limit_value, created_at, updated_at";

export async function listTeacherSequencesForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data: sequences, error: sequenceError } = await supabase
    .from("teacher_sequences")
    .select(TEACHER_SEQUENCE_FIELDS)
    .eq("teacher_space_id", spaceId)
    .order("updated_at", { ascending:false })
    .order("title", { ascending:true });
  if (sequenceError) throw sequenceError;

  const ids = (Array.isArray(sequences) ? sequences : []).map((item) => String(item.id || "")).filter(Boolean);
  if (!ids.length) return [];

  const { data: items, error: itemError } = await supabase
    .from("teacher_sequence_items")
    .select(TEACHER_SEQUENCE_ITEM_FIELDS)
    .in("sequence_id", ids)
    .order("position", { ascending:true })
    .order("created_at", { ascending:true });
  if (itemError) throw itemError;

  const bySequence = new Map();
  (Array.isArray(items) ? items : []).forEach((item) => {
    const key = String(item.sequence_id || "");
    if (!bySequence.has(key)) bySequence.set(key, []);
    bySequence.get(key).push(item);
  });

  return (sequences || []).map((sequence) => ({
    ...sequence,
    items:bySequence.get(String(sequence.id || "")) || []
  }));
}

export async function saveTeacherSequenceForSpace(teacherSpaceId, sequence = {}) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const title = cleanDisplayName(sequence.title);
  if (!title) throw new Error("Titre de séquence vide.");

  const cleanItems = (Array.isArray(sequence.items) ? sequence.items : []).map((item, index) => {
    const sourceType = String(item?.source_type || "").trim();
    if (!["catalog_activity", "teacher_activity"].includes(sourceType)) {
      throw new Error(`Source invalide pour l’activité ${index + 1}.`);
    }
    const sourceId = String(item?.source_id || "").trim();
    if (!sourceId) throw new Error(`Activité ${index + 1} introuvable.`);
    const itemTitle = cleanDisplayName(item?.title_snapshot || item?.title) || `Activité ${index + 1}`;
    const difficultyMode = String(item?.difficulty_mode || "fixed") === "adaptive" ? "adaptive" : "fixed";
    const difficultyLevel = difficultyMode === "adaptive"
      ? null
      : Math.max(1, Math.min(5, Math.trunc(Number(item?.difficulty_level) || 3)));
    const executionModeCandidate = String(item?.execution_limit_mode || "questions").trim();
    const executionMode = ["questions", "time", "intrinsic"].includes(executionModeCandidate)
      ? executionModeCandidate
      : "questions";
    const executionValue = executionMode === "intrinsic"
      ? null
      : Math.max(1, Math.trunc(Number(item?.execution_limit_value) || (executionMode === "time" ? 300 : 5)));
    return {
      position:index,
      source_type:sourceType,
      source_id:sourceId,
      title_snapshot:itemTitle,
      difficulty_mode:difficultyMode,
      difficulty_level:difficultyLevel,
      execution_limit_mode:executionMode,
      execution_limit_value:executionValue
    };
  });

  if (!cleanItems.length) throw new Error("Ajoutez au moins une activité à la séquence.");

  const existingId = normalizeUuid(sequence.id);
  let savedSequence = null;
  if (existingId) {
    const { data, error } = await supabase
      .from("teacher_sequences")
      .update({ title, title_normalized:normalizeConfigName(title) })
      .eq("id", existingId)
      .eq("teacher_space_id", spaceId)
      .select(TEACHER_SEQUENCE_FIELDS)
      .single();
    if (error) throw error;
    savedSequence = data;
  } else {
    const { data, error } = await supabase
      .from("teacher_sequences")
      .insert({ teacher_space_id:spaceId, title, title_normalized:normalizeConfigName(title) })
      .select(TEACHER_SEQUENCE_FIELDS)
      .single();
    if (error) throw error;
    savedSequence = data;
  }

  const sequenceId = String(savedSequence?.id || "");
  if (!sequenceId) throw new Error("Séquence introuvable après enregistrement.");

  const { error: deleteError } = await supabase
    .from("teacher_sequence_items")
    .delete()
    .eq("sequence_id", sequenceId);
  if (deleteError) throw deleteError;

  const { data: savedItems, error: itemsError } = await supabase
    .from("teacher_sequence_items")
    .insert(cleanItems.map((item) => ({ sequence_id:sequenceId, ...item })))
    .select(TEACHER_SEQUENCE_ITEM_FIELDS);
  if (itemsError) throw itemsError;

  const orderedItems = Array.isArray(savedItems)
    ? [...savedItems].sort((a, b) => (Number(a.position) || 0) - (Number(b.position) || 0))
    : [];
  return { ...savedSequence, items:orderedItems };
}

export async function deleteTeacherSequence(sequenceId) {
  const id = normalizeUuid(sequenceId);
  if (!id) throw new Error("Séquence invalide.");
  const { data: usage, error: usageError } = await supabase
    .from("activity_assignments")
    .select("id")
    .eq("source_type", "sequence")
    .eq("source_id", id)
    .limit(1);
  if (usageError) throw usageError;
  if (Array.isArray(usage) && usage.length) {
    throw new Error("Cette séquence est encore attribuée. Retire d’abord son attribution.");
  }
  const { error } = await supabase.from("teacher_sequences").delete().eq("id", id);
  if (error) throw error;
}

/* =========================
   ATTRIBUTION DIRECTE D’ACTIVITÉS
   ========================= */

const ACTIVITY_ASSIGNMENT_FIELDS = "id, teacher_space_id, source_type, source_id, title_snapshot, difficulty_mode, difficulty_level, execution_limit_mode, execution_limit_value, created_at, updated_at";
const ACTIVITY_ASSIGNMENT_TARGET_FIELDS = "id, assignment_id, target_type, teacher_class_id, student_id, created_at";

export async function listActivityAssignmentsForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data: assignments, error: assignmentError } = await supabase
    .from("activity_assignments")
    .select(ACTIVITY_ASSIGNMENT_FIELDS)
    .eq("teacher_space_id", spaceId)
    .order("created_at", { ascending:false });
  if (assignmentError) throw assignmentError;

  const ids = (Array.isArray(assignments) ? assignments : []).map((item) => String(item.id || "")).filter(Boolean);
  if (!ids.length) return [];

  const { data: targets, error: targetError } = await supabase
    .from("activity_assignment_targets")
    .select(ACTIVITY_ASSIGNMENT_TARGET_FIELDS)
    .in("assignment_id", ids)
    .order("created_at", { ascending:true });
  if (targetError) throw targetError;

  const byAssignment = new Map();
  (Array.isArray(targets) ? targets : []).forEach((target) => {
    const key = String(target.assignment_id || "");
    if (!byAssignment.has(key)) byAssignment.set(key, []);
    byAssignment.get(key).push(target);
  });

  return (assignments || []).map((assignment) => ({
    ...assignment,
    targets:byAssignment.get(String(assignment.id || "")) || []
  }));
}

export async function saveActivityAssignmentForSpace(teacherSpaceId, assignment = {}, targets = []) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const sourceType = String(assignment.source_type || "").trim();
  if (!["catalog_activity", "teacher_activity", "sequence"].includes(sourceType)) {
    throw new Error("Source d’attribution invalide.");
  }
  const sourceId = String(assignment.source_id || "").trim();
  if (!sourceId) throw new Error("Activité à attribuer introuvable.");
  const title = cleanDisplayName(assignment.title_snapshot || assignment.title);
  if (!title) throw new Error("Titre d’activité vide.");

  const difficultyMode = String(assignment.difficulty_mode || "fixed").trim() === "adaptive" ? "adaptive" : "fixed";
  const difficultyLevel = difficultyMode === "adaptive"
    ? null
    : Math.max(1, Math.min(5, Math.trunc(Number(assignment.difficulty_level) || 3)));
  const executionModeCandidate = String(assignment.execution_limit_mode || "questions").trim();
  const executionMode = ["questions", "time", "intrinsic"].includes(executionModeCandidate)
    ? executionModeCandidate
    : "questions";
  const executionValue = executionMode === "intrinsic"
    ? null
    : Math.max(1, Math.trunc(Number(assignment.execution_limit_value) || (executionMode === "time" ? 300 : 5)));

  const cleanTargets = (Array.isArray(targets) ? targets : []).map((target) => {
    const type = String(target?.target_type || "").trim();
    if (type === "class") {
      const classId = Number(target?.teacher_class_id);
      return Number.isFinite(classId) && classId > 0
        ? { target_type:"class", teacher_class_id:classId, student_id:null }
        : null;
    }
    if (type === "student") {
      const studentId = Number(target?.student_id);
      return Number.isFinite(studentId) && studentId > 0
        ? { target_type:"student", teacher_class_id:null, student_id:studentId }
        : null;
    }
    return null;
  }).filter(Boolean);

  if (!cleanTargets.length) throw new Error("Choisissez au moins un destinataire.");

  const { data, error } = await supabase
    .from("activity_assignments")
    .insert({
      teacher_space_id:spaceId,
      source_type:sourceType,
      source_id:sourceId,
      title_snapshot:title,
      difficulty_mode:difficultyMode,
      difficulty_level:difficultyLevel,
      execution_limit_mode:executionMode,
      execution_limit_value:executionValue
    })
    .select(ACTIVITY_ASSIGNMENT_FIELDS)
    .single();
  if (error) throw error;

  const assignmentId = String(data?.id || "");
  try {
    const { error: targetsError } = await supabase
      .from("activity_assignment_targets")
      .insert(cleanTargets.map((target) => ({ assignment_id:assignmentId, ...target })));
    if (targetsError) throw targetsError;
  } catch (error) {
    await supabase.from("activity_assignments").delete().eq("id", assignmentId);
    throw error;
  }

  return {
    ...data,
    targets:cleanTargets.map((target) => ({ assignment_id:assignmentId, ...target }))
  };
}

const DIRECT_LAUNCH_LINK_FIELDS = "id, teacher_space_id, token, source_type, source_id, title_snapshot, difficulty_mode, difficulty_level, execution_limit_mode, execution_limit_value, is_active, created_at, updated_at";

export async function saveDirectLaunchLinkForSpace(teacherSpaceId, link = {}) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const sourceType = String(link.source_type || "").trim();
  if (!["catalog_activity", "teacher_activity", "sequence"].includes(sourceType)) {
    throw new Error("Source de lien direct invalide.");
  }
  const sourceId = String(link.source_id || "").trim();
  if (!sourceId) throw new Error("Ressource à partager introuvable.");
  const title = cleanDisplayName(link.title_snapshot || link.title);
  if (!title) throw new Error("Titre de ressource vide.");

  const difficultyMode = String(link.difficulty_mode || "fixed").trim() === "adaptive" ? "adaptive" : "fixed";
  const difficultyLevel = difficultyMode === "adaptive"
    ? null
    : Math.max(1, Math.min(5, Math.trunc(Number(link.difficulty_level) || 3)));
  const executionCandidate = String(link.execution_limit_mode || "questions").trim();
  const executionMode = ["questions", "time", "intrinsic"].includes(executionCandidate) ? executionCandidate : "questions";
  const executionValue = executionMode === "intrinsic"
    ? null
    : Math.max(1, Math.trunc(Number(link.execution_limit_value) || (executionMode === "time" ? 300 : 5)));

  const payload = {
    teacher_space_id:spaceId,
    source_type:sourceType,
    source_id:sourceId,
    title_snapshot:title,
    difficulty_mode:difficultyMode,
    difficulty_level:difficultyLevel,
    execution_limit_mode:executionMode,
    execution_limit_value:executionValue,
    is_active:true
  };

  const { data, error } = await supabase
    .from("direct_launch_links")
    .upsert(payload, { onConflict:"teacher_space_id,source_type,source_id" })
    .select(DIRECT_LAUNCH_LINK_FIELDS)
    .single();
  if (error) throw error;
  return data;
}

export async function deleteActivityAssignment(assignmentId) {
  const id = normalizeUuid(assignmentId);
  if (!id) throw new Error("Attribution invalide.");
  const { error } = await supabase.from("activity_assignments").delete().eq("id", id);
  if (error) throw error;
}

export async function listMissionFoldersForSpace(teacherSpaceId) {
  const { data, error } = await supabase
    .from("mission_folders")
    .select("id, teacher_space_id, parent_id, name, display_order, created_at, updated_at")
    .eq("teacher_space_id", teacherSpaceId)
    .order("display_order", { ascending: true })
    .order("name", { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createMissionFolderForSpace(teacherSpaceId, { name, parent_id = null } = {}) {
  const cleanName = cleanDisplayName(name);
  if (!cleanName) throw new Error("Nom de dossier vide.");
  const folders = await listMissionFoldersForSpace(teacherSpaceId);
  const safeParentId = String(parent_id || "").trim() || null;
  const nextOrder = folders.filter((folder) => String(folder.parent_id || "") === String(safeParentId || ""))
    .reduce((max, folder) => Math.max(max, Number(folder.display_order) || 0), -1) + 1;
  const { data, error } = await supabase.from("mission_folders").insert({
    teacher_space_id: teacherSpaceId,
    parent_id: safeParentId,
    name: cleanName,
    display_order: nextOrder
  }).select("id, teacher_space_id, parent_id, name, display_order, created_at, updated_at").single();
  if (error) throw error;
  return data;
}

export async function updateMissionFolder(folderId, updates = {}) {
  const payload = {};
  if ("name" in updates) payload.name = cleanDisplayName(updates.name);
  if ("parent_id" in updates) payload.parent_id = String(updates.parent_id || "").trim() || null;
  if ("display_order" in updates) payload.display_order = Math.max(0, Math.trunc(Number(updates.display_order) || 0));
  const { data, error } = await supabase.from("mission_folders").update(payload).eq("id", folderId)
    .select("id, teacher_space_id, parent_id, name, display_order, created_at, updated_at").single();
  if (error) throw error;
  return data;
}

export async function deleteMissionFolder(folderId) {
  const { error } = await supabase.from("mission_folders").delete().eq("id", folderId);
  if (error) throw error;
}

export async function listMissionsForSpace(teacherSpaceId) {
  const { data, error } = await supabase
    .from("missions")
    .select("id, teacher_space_id, folder_id, title, title_normalized, description, status, inactive_reason, current_run, answer_mode, intent_mode, question_count, question_time_seconds, answer_display_seconds, transition_seconds, mission_time_seconds, instructions, display_order, created_at, updated_at")
    .eq("teacher_space_id", teacherSpaceId)
    .order("display_order", { ascending: true })
    .order("title", { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function updateMissionPlacement(missionId, updates = {}) {
  const id = normalizeUuid(missionId);
  if (!id) throw new Error("Mission invalide.");
  const payload = {};
  if ("folder_id" in updates) payload.folder_id = normalizeNullableUuid(updates.folder_id);
  if ("display_order" in updates) payload.display_order = Math.max(0, Math.trunc(Number(updates.display_order) || 0));
  if (!Object.keys(payload).length) throw new Error("Aucun déplacement de mission à enregistrer.");

  const { data, error } = await supabase
    .from("missions")
    .update(payload)
    .eq("id", id)
    .select("id, teacher_space_id, folder_id, title, title_normalized, description, status, inactive_reason, current_run, answer_mode, intent_mode, question_count, question_time_seconds, answer_display_seconds, transition_seconds, mission_time_seconds, instructions, display_order, created_at, updated_at")
    .single();
  if (error) throw error;
  return data;
}

export async function listMissionSteps(missionId) {
  const { data, error } = await supabase
    .from("mission_steps")
    .select("id, mission_id, catalog_activity_id, position, difficulty_mode, difficulty_level, step_options_json, created_at, updated_at")
    .eq("mission_id", missionId)
    .order("position", { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function listMissionAssignments(missionId) {
  const { data, error } = await supabase
    .from("mission_assignments")
    .select("id, mission_id, target_type, teacher_class_id, student_id, created_at")
    .eq("mission_id", missionId);
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function saveMissionForSpace(teacherSpaceId, mission = {}, steps = [], assignments = []) {
  const title = cleanDisplayName(mission.title);
  if (!title) throw new Error("Titre de mission vide.");
  const missionStatus = ["active", "inactive"].includes(String(mission.status || "draft").trim())
    ? String(mission.status || "draft").trim()
    : "draft";
  const payload = {
    teacher_space_id: teacherSpaceId,
    folder_id: String(mission.folder_id || "").trim() || null,
    title,
    title_normalized: normalizeConfigName(title),
    description: String(mission.description || "").trim(),
    status: missionStatus,
    inactive_reason: missionStatus === "inactive" ? "manual" : null,
    answer_mode: String(mission.answer_mode || "student_input").trim() === "manual_validation" ? "manual_validation" : "student_input",
    intent_mode: String(mission.intent_mode || "practice").trim() === "evaluation" ? "evaluation" : "practice",
    question_count: Math.max(1, Math.trunc(Number(mission.question_count) || 5)),
    question_time_seconds: mission.question_time_seconds == null || mission.question_time_seconds === "" ? null : Math.max(0, Math.trunc(Number(mission.question_time_seconds) || 0)),
    answer_display_seconds: mission.answer_display_seconds == null || mission.answer_display_seconds === "" ? null : Math.max(0, Math.trunc(Number(mission.answer_display_seconds) || 0)),
    transition_seconds: Math.max(0, Math.trunc(Number(mission.transition_seconds) || 0)),
    mission_time_seconds: mission.mission_time_seconds == null || mission.mission_time_seconds === "" ? null : Math.max(0, Math.trunc(Number(mission.mission_time_seconds) || 0)),
    instructions: String(mission.instructions || "").trim() || null,
    display_order: Math.max(0, Math.trunc(Number(mission.display_order) || 0))
  };

  let savedMission;
  if (mission.id) {
    const { data, error } = await supabase.from("missions").update(payload).eq("id", mission.id).select("*").single();
    if (error) throw error;
    savedMission = data;
  } else {
    const existing = await listMissionsForSpace(teacherSpaceId);
    payload.display_order = existing.reduce((max, item) => Math.max(max, Number(item.display_order) || 0), -1) + 1;
    const { data, error } = await supabase.from("missions").insert(payload).select("*").single();
    if (error) throw error;
    savedMission = data;
  }

  const missionId = savedMission.id;
  await supabase.from("mission_steps").delete().eq("mission_id", missionId);
  const cleanSteps = (Array.isArray(steps) ? steps : []).map((step, index) => ({
    mission_id: missionId,
    catalog_activity_id: String(step.catalog_activity_id || step.id || "").trim(),
    position: index,
    difficulty_mode: String(step.difficulty_mode || "normal").trim() || "normal",
    difficulty_level: Math.max(1, Math.min(5, Math.trunc(Number(step.difficulty_level) || 3))),
    step_options_json: step.step_options_json && typeof step.step_options_json === "object" ? step.step_options_json : {}
  })).filter((step) => step.catalog_activity_id);
  if (cleanSteps.length) {
    const { error } = await supabase.from("mission_steps").insert(cleanSteps);
    if (error) throw error;
  }

  await supabase.from("mission_assignments").delete().eq("mission_id", missionId);
  const cleanAssignments = (Array.isArray(assignments) ? assignments : []).map((assignment) => {
    const targetType = String(assignment.target_type || "").trim();
    if (targetType === "class") {
      const classId = Number(assignment.teacher_class_id);
      return Number.isFinite(classId) && classId > 0 ? { mission_id: missionId, target_type: "class", teacher_class_id: classId } : null;
    }
    if (targetType === "student") {
      const studentId = Number(assignment.student_id);
      return Number.isFinite(studentId) && studentId > 0 ? { mission_id: missionId, target_type: "student", student_id: studentId } : null;
    }
    return null;
  }).filter(Boolean);
  if (cleanAssignments.length) {
    const { error } = await supabase.from("mission_assignments").insert(cleanAssignments);
    if (error) throw error;
  }

  return savedMission;
}

export async function setMissionInactive(missionId) {
  const { data, error } = await supabase
    .from("missions")
    .update({ status: "inactive", inactive_reason: "manual" })
    .eq("id", missionId)
    .eq("status", "active")
    .select("id, status, current_run")
    .maybeSingle();
  if (error) throw error;
  return data || null;
}

export async function reactivateMission(missionId) {
  const { data, error } = await supabase.rpc("reactivate_mission_as_teacher", {
    p_mission_id: String(missionId || "").trim()
  });
  if (error) throw error;
  return Array.isArray(data) ? (data[0] || null) : (data || null);
}

export async function deleteMissionPermanently(missionId) {
  const { error } = await supabase.from("missions").delete().eq("id", missionId);
  if (error) throw error;
}

export async function isCurrentUserSuperAdmin() {
  const { data, error } = await supabase.rpc("is_super_admin");
  if (error) {
    console.warn("Vérification super-admin impossible.", error);
    return false;
  }
  return data === true;
}

export async function listCatalogActivitiesForAdmin({ includeArchived = false } = {}) {
  let query = supabase
    .from("catalog_activities")
    .select("id, pedagogical_node_id, tool_id, title, description, adventure_tier, display_order, status, default_visible, levels_json, created_at, updated_at")
    .neq("id", "system.quiz.direct");

  if (!includeArchived) query = query.neq("status", "archived");

  const { data, error } = await query
    .order("pedagogical_node_id", { ascending: true })
    .order("adventure_tier", { ascending: true })
    .order("display_order", { ascending: true })
    .order("title", { ascending: true });

  if (error) throw error;
  return sortCatalogActivities(Array.isArray(data) ? data.map(normalizeCatalogActivity) : []);
}


export async function listAdventureDefaultMenuSlots(gradeLevel) {
  const safeGrade = normalizeAdventureGradeLevel(gradeLevel);
  const { data, error } = await supabase
    .from("adventure_default_menu_slots")
    .select("grade_level, menu_number, day_number, slot_number, item_type, grade_folder_id, catalog_activity_id, execution_limit, created_at, updated_at")
    .eq("grade_level", safeGrade)
    .order("menu_number", { ascending: true })
    .order("day_number", { ascending: true })
    .order("slot_number", { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data.map(normalizeAdventureMenuSlot) : [];
}

export async function saveAdventureDefaultMenuSlots(gradeLevel, items = []) {
  const safeGrade = normalizeAdventureGradeLevel(gradeLevel);
  const slots = (Array.isArray(items) ? items : [])
    .map((item) => normalizeAdventureMenuSlot({ ...item, grade_level: safeGrade }))
    .filter((item) => item.item_type === "objective" || item.item_type === "activity")
    .map((item) => ({
      menu_number: item.menu_number,
      day_number: item.day_number,
      slot_number: item.slot_number,
      item_type: item.item_type,
      grade_folder_id: item.item_type === "objective" ? item.grade_folder_id : null,
      catalog_activity_id: item.item_type === "activity" ? item.catalog_activity_id : null,
      execution_limit: item.execution_limit
    }));

  const { error } = await supabase.rpc("replace_adventure_default_menu", {
    p_grade_level: safeGrade,
    p_slots: slots
  });
  if (error) throw error;
  return listAdventureDefaultMenuSlots(safeGrade);
}

export async function listTeacherAdventureMenuSlots(teacherSpaceId, gradeLevel) {
  const safeTeacherSpaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const safeGrade = normalizeAdventureGradeLevel(gradeLevel);
  const { data, error } = await supabase
    .from("teacher_adventure_menu_slots")
    .select("teacher_space_id, grade_level, menu_number, day_number, slot_number, item_type, grade_folder_id, catalog_activity_id, execution_limit, created_at, updated_at")
    .eq("teacher_space_id", safeTeacherSpaceId)
    .eq("grade_level", safeGrade)
    .order("menu_number", { ascending: true })
    .order("day_number", { ascending: true })
    .order("slot_number", { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data.map(normalizeAdventureMenuSlot) : [];
}

export async function saveTeacherAdventureMenuSlot(teacherSpaceId, item = {}) {
  const safeTeacherSpaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const normalized = normalizeAdventureMenuSlot({
    ...item,
    teacher_space_id: safeTeacherSpaceId
  });
  const payload = {
    teacher_space_id: safeTeacherSpaceId,
    grade_level: normalized.grade_level,
    menu_number: normalized.menu_number,
    day_number: normalized.day_number,
    slot_number: normalized.slot_number,
    item_type: normalized.item_type,
    grade_folder_id: normalized.item_type === "objective" ? normalized.grade_folder_id : null,
    catalog_activity_id: normalized.item_type === "activity" ? normalized.catalog_activity_id : null,
    execution_limit: normalized.execution_limit,
    updated_at: new Date().toISOString()
  };

  const { data, error } = await supabase
    .from("teacher_adventure_menu_slots")
    .upsert(payload, {
      onConflict: "teacher_space_id,grade_level,menu_number,day_number,slot_number"
    })
    .select("teacher_space_id, grade_level, menu_number, day_number, slot_number, item_type, grade_folder_id, catalog_activity_id, execution_limit, created_at, updated_at")
    .single();

  if (error) throw error;
  return normalizeAdventureMenuSlot(data);
}

export async function deleteTeacherAdventureMenuSlot(teacherSpaceId, gradeLevel, menuNumber, dayNumber, slotNumber) {
  const safeTeacherSpaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const safeGrade = normalizeAdventureGradeLevel(gradeLevel);
  const { error } = await supabase
    .from("teacher_adventure_menu_slots")
    .delete()
    .eq("teacher_space_id", safeTeacherSpaceId)
    .eq("grade_level", safeGrade)
    .eq("menu_number", normalizeAdventureMenuNumber(menuNumber))
    .eq("day_number", normalizeAdventureDayNumber(dayNumber))
    .eq("slot_number", normalizeAdventureSlotNumber(slotNumber));
  if (error) throw error;
}

export async function deleteTeacherAdventureMenuSlotsForGrade(teacherSpaceId, gradeLevel) {
  const safeTeacherSpaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const safeGrade = normalizeAdventureGradeLevel(gradeLevel);
  const { error } = await supabase
    .from("teacher_adventure_menu_slots")
    .delete()
    .eq("teacher_space_id", safeTeacherSpaceId)
    .eq("grade_level", safeGrade);
  if (error) throw error;
}

export async function listAdventureClassCursors(teacherClassIds = [], gradeLevel) {
  const classIds = [...new Set((Array.isArray(teacherClassIds) ? teacherClassIds : [])
    .map((value) => Number(value))
    .filter((value) => Number.isSafeInteger(value) && value > 0))];
  if (!classIds.length) return [];

  const safeGrade = normalizeAdventureGradeLevel(gradeLevel);
  const { data, error } = await supabase
    .from("adventure_class_cursors")
    .select("teacher_class_id, grade_level, menu_number, day_number, is_enabled, created_at, updated_at")
    .in("teacher_class_id", classIds)
    .eq("grade_level", safeGrade)
    .order("teacher_class_id", { ascending: true });

  if (error) throw error;
  return (Array.isArray(data) ? data : []).map(normalizeAdventureClassCursor);
}

export async function saveAdventureClassCursor(teacherClassId, gradeLevel, updates = {}) {
  const safeClassId = Number(teacherClassId);
  if (!Number.isSafeInteger(safeClassId) || safeClassId <= 0) {
    throw new Error("Classe Aventure invalide.");
  }

  const payload = {
    teacher_class_id: safeClassId,
    grade_level: normalizeAdventureGradeLevel(gradeLevel),
    menu_number: normalizeAdventureMenuNumber(updates?.menu_number),
    day_number: normalizeAdventureDayNumber(updates?.day_number),
    is_enabled: updates?.is_enabled === true,
    updated_at: new Date().toISOString()
  };

  const { data, error } = await supabase
    .from("adventure_class_cursors")
    .upsert(payload, { onConflict: "teacher_class_id,grade_level" })
    .select("teacher_class_id, grade_level, menu_number, day_number, is_enabled, created_at, updated_at")
    .single();

  if (error) throw error;
  return normalizeAdventureClassCursor(data);
}

function normalizeAdventureClassCursor(item = {}) {
  return {
    ...item,
    teacher_class_id: Number(item?.teacher_class_id) || null,
    grade_level: normalizeAdventureGradeLevel(item?.grade_level),
    menu_number: normalizeAdventureMenuNumber(item?.menu_number),
    day_number: normalizeAdventureDayNumber(item?.day_number),
    is_enabled: item?.is_enabled === true
  };
}

function normalizeAdventureMenuSlot(item = {}) {
  const itemType = ["objective", "activity", "empty"].includes(String(item?.item_type || "").trim())
    ? String(item.item_type).trim()
    : "empty";
  return {
    ...item,
    teacher_space_id: Number(item?.teacher_space_id) || null,
    grade_level: normalizeAdventureGradeLevel(item?.grade_level),
    menu_number: normalizeAdventureMenuNumber(item?.menu_number),
    day_number: normalizeAdventureDayNumber(item?.day_number),
    slot_number: normalizeAdventureSlotNumber(item?.slot_number),
    item_type: itemType,
    grade_folder_id: itemType === "objective" ? String(item?.grade_folder_id || "").trim() || null : null,
    catalog_activity_id: itemType === "activity" ? String(item?.catalog_activity_id || "").trim() || null : null,
    execution_limit: normalizeAdventureExecutionLimit(item?.execution_limit ?? item?.executionLimit)
  };
}

function normalizeAdventureExecutionLimit(value) {
  const raw = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const mode = String(raw.mode || "questions").trim() === "time" ? "time" : "questions";
  const fallback = mode === "time" ? 180 : 5;
  const amount = Math.max(1, Math.trunc(Number(raw.value) || fallback));
  return { mode, value: mode === "time" ? Math.min(7200, amount) : Math.min(200, amount) };
}

function normalizeAdventureGradeLevel(value) {
  const grade = normalizeCatalogGradeLevel(value);
  if (!grade) throw new Error("Niveau Aventure invalide.");
  return grade;
}

function normalizeAdventureMenuNumber(value) {
  return Math.max(1, Math.min(34, Math.trunc(Number(value) || 1)));
}

function normalizeAdventureDayNumber(value) {
  return Math.max(1, Math.min(4, Math.trunc(Number(value) || 1)));
}

function normalizeAdventureSlotNumber(value) {
  return Math.max(1, Math.min(6, Math.trunc(Number(value) || 1)));
}

export async function listAdventureObjectivesForSpace(teacherSpaceId) {
  const safeTeacherSpaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("teacher_adventure_objectives")
    .select("teacher_space_id, grade_folder_id, display_order, is_enabled, created_at, updated_at")
    .eq("teacher_space_id", safeTeacherSpaceId)
    .order("display_order", { ascending: true })
    .order("grade_folder_id", { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data.map(normalizeTeacherAdventureObjective) : [];
}

export async function saveAdventureObjectivesForSpace(teacherSpaceId, items = []) {
  const safeTeacherSpaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const payload = (Array.isArray(items) ? items : []).map((item, index) => {
    const gradeFolderId = String(item?.grade_folder_id || "").trim();
    if (!gradeFolderId) return null;
    return {
      teacher_space_id: safeTeacherSpaceId,
      grade_folder_id: gradeFolderId,
      display_order: Math.max(0, Math.trunc(Number(item?.display_order) || index)),
      is_enabled: item?.is_enabled !== false,
      updated_at: new Date().toISOString()
    };
  }).filter(Boolean);

  if (!payload.length) return [];

  const { data, error } = await supabase
    .from("teacher_adventure_objectives")
    .upsert(payload, { onConflict: "teacher_space_id,grade_folder_id" })
    .select("teacher_space_id, grade_folder_id, display_order, is_enabled, created_at, updated_at");

  if (error) throw error;
  return Array.isArray(data) ? data.map(normalizeTeacherAdventureObjective) : [];
}

function normalizeTeacherAdventureObjective(item = {}) {
  const displayOrder = Number(item?.display_order);
  return {
    ...item,
    teacher_space_id: Number(item?.teacher_space_id) || null,
    grade_folder_id: String(item?.grade_folder_id || "").trim(),
    display_order: Number.isFinite(displayOrder) ? Math.max(0, Math.trunc(displayOrder)) : 0,
    is_enabled: item?.is_enabled !== false
  };
}

export async function saveCatalogActivityAsAdmin(activity = {}) {
  const id = String(activity.id || "").trim().toLowerCase();
  const title = cleanDisplayName(activity.title || activity.config_name);
  const categoryId = String(activity.pedagogical_node_id || activity.folder_id || "").trim();
  const toolId = String(activity.tool_id || "").trim();
  if (!id) throw new Error("Identifiant d’activité vide.");
  if (!/^[a-z0-9][a-z0-9._-]{1,160}$/.test(id)) {
    throw new Error("Identifiant invalide. Utilise minuscules, chiffres, points, tirets ou underscores.");
  }
  if (!title) throw new Error("Titre d’activité vide.");
  if (!categoryId) throw new Error("Adresse pédagogique obligatoire.");
  if (!toolId) throw new Error("Outil obligatoire.");

  const payload = {
    id,
    pedagogical_node_id: categoryId,
    tool_id: toolId,
    title,
    description: String(activity.description || "").trim(),
    adventure_tier: Math.max(1, Math.trunc(Number(activity.adventure_tier) || 1)),
    display_order: Math.max(0, Math.trunc(Number(activity.display_order) || 0)),
    status: ["draft", "published", "archived"].includes(String(activity.status || "draft").trim())
      ? String(activity.status || "draft").trim()
      : "draft",
    default_visible: activity.default_visible !== false,
    levels_json: activity.levels_json && typeof activity.levels_json === "object" && !Array.isArray(activity.levels_json)
      ? activity.levels_json
      : { "1": { settings: {} }, "2": { settings: {} }, "3": { settings: {} }, "4": { settings: {} }, "5": { settings: {} } },
    updated_at: new Date().toISOString()
  };

  const { data, error } = await supabase
    .from("catalog_activities")
    .upsert(payload, { onConflict: "id" })
    .select("id, pedagogical_node_id, tool_id, title, description, adventure_tier, display_order, status, default_visible, levels_json, created_at, updated_at")
    .single();

  if (error) throw error;
  return normalizeCatalogActivity(data);
}

export async function getCatalogActivityUsageAsAdmin(activityId) {
  const id = String(activityId || "").trim().toLowerCase();
  if (!id) throw new Error("Activité introuvable.");
  const { data, error } = await supabase.rpc("get_catalog_activity_usage_as_admin", {
    p_activity_id: id
  });
  if (error) throw error;
  return Array.isArray(data) && data.length ? data[0] : {
    catalog_activity_id: id,
    mission_steps_count: 0,
    missions_count: 0,
    progress_count: 0,
    sessions_count: 0,
    visibility_count: 0
  };
}

export async function deleteCatalogActivityAsAdmin(activityId) {
  const id = String(activityId || "").trim().toLowerCase();
  if (!id) throw new Error("Activité introuvable.");
  const { error } = await supabase.rpc("delete_catalog_activity_cascade", {
    p_activity_id: id
  });
  if (error) throw error;
}

/* =========================
   QUIZ SUPABASE
   ========================= */

const QUIZ_FOLDER_FIELDS = "id, teacher_space_id, parent_id, name, display_order, is_system, created_at, updated_at";
const QUIZ_FIELDS = "id, teacher_space_id, folder_id, title, document, schema_version, display_order, is_system, created_at, updated_at";
const QUIZ_SUMMARY_FIELDS = "id, teacher_space_id, folder_id, title, schema_version, display_order, is_system, created_at, updated_at";
const RESOURCE_FOLDER_FIELDS = "id, teacher_space_id, parent_id, name, metadata, display_order, is_system, created_at, updated_at";
const RESOURCE_FIELDS = "id, teacher_space_id, folder_id, title, resource_type, storage_bucket, storage_path, mime_type, size_bytes, width, height, duration_seconds, alt_text, tags, metadata, display_order, is_system, created_at, updated_at";
const TEACHER_RESOURCE_BUCKET = "teacher-resources";
const SYSTEM_IMAGE_BUCKET = "images";

function normalizePositiveTeacherSpaceId(value) {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new Error("Espace enseignant invalide.");
  }
  return id;
}

function normalizeUuid(value) {
  const id = String(value || "").trim().toLowerCase();
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id)
    ? id
    : "";
}

function cloneJsonValue(value) {
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function collectQuizResourceIds(document) {
  const result = new Set();
  const visit = (value) => {
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      value.forEach(visit);
      return;
    }
    const kind = String(value.kind || value.type || "").trim().toLowerCase();
    if (kind === "resource" || kind === "supabase-resource" || kind === "personal-resource" || kind === "system-resource") {
      const id = normalizeUuid(value.resourceId || value.resource_id || value.id);
      if (id) result.add(id);
    }
    Object.values(value).forEach(visit);
  };
  visit(document);
  return Array.from(result);
}

function hasForbiddenSystemQuizSource(document) {
  const forbiddenKinds = new Set([
    "local-upload",
    "local-recording",
    "local-file",
    "site-asset",
    "system",
    "asset",
    "blob"
  ]);
  let forbidden = false;
  const visit = (value) => {
    if (forbidden || !value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      value.forEach(visit);
      return;
    }
    const kind = String(value.kind || "").trim().toLowerCase();
    if (forbiddenKinds.has(kind)) {
      forbidden = true;
      return;
    }
    Object.values(value).forEach(visit);
  };
  visit(document);
  return forbidden;
}

async function assertSystemQuizResourcesAreSystem(resourceIds) {
  const ids = Array.from(new Set((Array.isArray(resourceIds) ? resourceIds : []).map(normalizeUuid).filter(Boolean)));
  if (!ids.length) return;

  const { data, error } = await supabase
    .from("resources")
    .select("id, is_system")
    .in("id", ids);
  if (error) throw error;

  const rows = Array.isArray(data) ? data : [];
  const allowedIds = new Set(rows.filter((row) => row?.is_system === true).map((row) => normalizeUuid(row.id)).filter(Boolean));
  if (allowedIds.size !== ids.length || ids.some((id) => !allowedIds.has(id))) {
    throw new Error("Un quiz système ne peut utiliser que des ressources système.");
  }
}

async function syncQuizResourceLinks(quizId, document) {
  const id = normalizeUuid(quizId);
  if (!id) return;
  const resourceIds = collectQuizResourceIds(document);
  const { error: deleteError } = await supabase
    .from("quiz_resources")
    .delete()
    .eq("quiz_id", id);
  if (deleteError) throw deleteError;
  if (!resourceIds.length) return;
  const { error: insertError } = await supabase
    .from("quiz_resources")
    .insert(resourceIds.map((resourceId) => ({ quiz_id:id, resource_id:resourceId })));
  if (insertError) throw insertError;
}


function normalizeNullableUuid(value) {
  return normalizeUuid(value) || null;
}

function normalizeQuizFolderRecord(row = {}, index = 0) {
  return {
    id: String(row.id || ""),
    teacher_space_id: row.teacher_space_id == null ? null : Number(row.teacher_space_id),
    parent_id: row.parent_id ? String(row.parent_id) : null,
    name: cleanDisplayName(row.name) || "Dossier sans nom",
    display_order: Number.isFinite(Number(row.display_order)) ? Number(row.display_order) : index,
    is_system: row.is_system === true,
    created_at: String(row.created_at || ""),
    updated_at: String(row.updated_at || row.created_at || "")
  };
}

function normalizeQuizRecord(row = {}, index = 0) {
  const document = row.document && typeof row.document === "object" && !Array.isArray(row.document)
    ? cloneJsonValue(row.document)
    : {};
  return {
    ...document,
    version: Number(document.version || row.schema_version) || 1,
    id: String(row.id || document.id || ""),
    title: cleanDisplayName(row.title || document.title) || "Quiz sans titre",
    teacher_space_id: row.teacher_space_id == null ? null : Number(row.teacher_space_id),
    folder_id: row.folder_id ? String(row.folder_id) : null,
    display_order: Number.isFinite(Number(row.display_order)) ? Number(row.display_order) : index,
    is_system: row.is_system === true,
    created_at: String(row.created_at || document.created_at || ""),
    updated_at: String(row.updated_at || document.updated_at || row.created_at || "")
  };
}

export async function listQuizFoldersForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("quiz_folders")
    .select(QUIZ_FOLDER_FIELDS)
    .or(`teacher_space_id.eq.${spaceId},is_system.eq.true`)
    .order("is_system", { ascending: true })
    .order("display_order", { ascending: true })
    .order("name", { ascending: true });

  if (error) throw error;
  return (Array.isArray(data) ? data : []).map(normalizeQuizFolderRecord);
}

export async function createQuizFolderForSpace(teacherSpaceId, folder = {}) {
  const isSystem = folder?.is_system === true;
  const spaceId = isSystem ? null : normalizePositiveTeacherSpaceId(teacherSpaceId);
  const name = cleanDisplayName(folder.name);
  if (!name) throw new Error("Nom de dossier vide.");

  const { data, error } = await supabase
    .from("quiz_folders")
    .insert({
      teacher_space_id: spaceId,
      parent_id: normalizeNullableUuid(folder.parent_id),
      name,
      display_order: Number.isFinite(Number(folder.display_order)) ? Number(folder.display_order) : 0,
      is_system: isSystem
    })
    .select(QUIZ_FOLDER_FIELDS)
    .single();

  if (error) throw error;
  return normalizeQuizFolderRecord(data);
}

export async function updateQuizFolder(folderId, updates = {}) {
  const id = normalizeUuid(folderId);
  if (!id) throw new Error("Dossier de quiz invalide.");
  const isSystem = updates?.is_system === true;

  const payload = {};
  if ("name" in updates) {
    const name = cleanDisplayName(updates.name);
    if (!name) throw new Error("Nom de dossier vide.");
    payload.name = name;
  }
  if ("parent_id" in updates) payload.parent_id = normalizeNullableUuid(updates.parent_id);
  if ("display_order" in updates) payload.display_order = Number(updates.display_order) || 0;

  const { data, error } = await supabase
    .from("quiz_folders")
    .update(payload)
    .eq("id", id)
    .eq("is_system", isSystem)
    .select(QUIZ_FOLDER_FIELDS)
    .single();

  if (error) throw error;
  return normalizeQuizFolderRecord(data);
}

export async function deleteQuizFolder(folderId, options = {}) {
  const id = normalizeUuid(folderId);
  if (!id) throw new Error("Dossier de quiz invalide.");
  const { error } = await supabase
    .from("quiz_folders")
    .delete()
    .eq("id", id)
    .eq("is_system", options?.is_system === true);
  if (error) throw error;
}

export async function listQuizzesForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("quizzes")
    .select(QUIZ_FIELDS)
    .or(`teacher_space_id.eq.${spaceId},is_system.eq.true`)
    .order("is_system", { ascending: true })
    .order("display_order", { ascending: true })
    .order("title", { ascending: true });

  if (error) throw error;
  return (Array.isArray(data) ? data : []).map(normalizeQuizRecord);
}

export async function updateQuizPlacement(quizId, updates = {}, options = {}) {
  const id = normalizeUuid(quizId);
  if (!id) throw new Error("Quiz invalide.");
  const payload = {};
  if ("folder_id" in updates) payload.folder_id = normalizeNullableUuid(updates.folder_id);
  if ("display_order" in updates) payload.display_order = Math.max(0, Number(updates.display_order) || 0);
  if (!Object.keys(payload).length) throw new Error("Aucun déplacement de quiz à enregistrer.");

  const { data, error } = await supabase
    .from("quizzes")
    .update(payload)
    .eq("id", id)
    .eq("is_system", options?.is_system === true)
    .select(QUIZ_FIELDS)
    .single();
  if (error) throw error;
  return normalizeQuizRecord(data);
}

// Le sélecteur de quiz n'a besoin que de l'arborescence. Éviter de transférer
// tous les documents (qui peuvent contenir des centaines de variantes).
export async function listQuizSummariesForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("quizzes")
    .select(QUIZ_SUMMARY_FIELDS)
    .or(`teacher_space_id.eq.${spaceId},is_system.eq.true`)
    .order("is_system", { ascending: true })
    .order("display_order", { ascending: true })
    .order("title", { ascending: true });

  if (error) throw error;
  return (Array.isArray(data) ? data : []).map(normalizeQuizRecord);
}

export async function getQuizForSpace(teacherSpaceId, quizId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const id = normalizeUuid(quizId);
  if (!id) throw new Error("Quiz invalide.");

  const { data, error } = await supabase
    .from("quizzes")
    .select(QUIZ_FIELDS)
    .eq("id", id)
    .or(`teacher_space_id.eq.${spaceId},is_system.eq.true`)
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("Quiz introuvable.");
  return normalizeQuizRecord(data);
}

const DIRECT_QUIZ_CATALOG_ACTIVITY_ID = "system.quiz.direct";

async function refreshDirectQuizMissionStepsForSpace(teacherSpaceId, quiz = {}) {
  if (quiz?.is_system === true) return;
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const snapshot = normalizeQuizSnapshot(quiz);
  const quizId = String(snapshot.id || quiz?.id || "").trim();
  if (!quizId) return;

  const title = cleanDisplayName(snapshot.title || quiz?.title) || "Quiz sans titre";
  const resourceIds = collectQuizResourceIds(snapshot);

  const { data: missionRows, error: missionError } = await supabase
    .from("missions")
    .select("id")
    .eq("teacher_space_id", spaceId);
  if (missionError) throw missionError;
  const missionIds = (Array.isArray(missionRows) ? missionRows : []).map((row) => String(row.id || "")).filter(Boolean);
  if (!missionIds.length) return;

  const { data: stepRows, error: stepError } = await supabase
    .from("mission_steps")
    .select("id, mission_id, catalog_activity_id, step_options_json")
    .in("mission_id", missionIds)
    .eq("catalog_activity_id", DIRECT_QUIZ_CATALOG_ACTIVITY_ID);
  if (stepError) throw stepError;

  const linkedSteps = (Array.isArray(stepRows) ? stepRows : []).filter((step) => (
    String(step?.step_options_json?.direct_quiz?.quiz_id || "") === quizId
    && step?.step_options_json?.direct_quiz?.follow_updates !== false
  ));
  if (!linkedSteps.length) return;

  await Promise.all(linkedSteps.map(async (step) => {
    const options = cloneJsonValue(step.step_options_json && typeof step.step_options_json === "object" ? step.step_options_json : {});
    const storedSettings = options.settings && typeof options.settings === "object" ? options.settings : {};
    const runtimeSettings = normalizeQuizRuntimeSettings({
      drawMode:storedSettings.drawMode ?? storedSettings.draw_mode ?? "random",
      questionSelection:storedSettings.questionSelection ?? storedSettings.question_selection ?? { mode:"all", questionKeys:[] },
      timeLimitSec:storedSettings.timeLimitSec ?? storedSettings.time_limit_sec ?? 0,
      autoExitOnComplete:false
    }, snapshot);
    const selectedQuestions = filterQuizSnapshotBySelection(snapshot, runtimeSettings.questionSelection);
    const questionCount = Math.max(1, selectedQuestions.length || 1);
    options.direct_quiz = {
      ...(options.direct_quiz && typeof options.direct_quiz === "object" ? options.direct_quiz : {}),
      quiz_id: quizId,
      title,
      question_count: questionCount,
      resource_ids: resourceIds
    };
    options.execution_limit = { mode:"questions", value:questionCount };
    options.settings = {
      ...storedSettings,
      quizId,
      quizTitle:title,
      sourceInstruction:String(snapshot.instruction || ""),
      drawMode:runtimeSettings.drawMode,
      questionSelection:runtimeSettings.questionSelection,
      timeLimitSec:runtimeSettings.timeLimitSec,
      autoExitOnComplete:false,
      quizSnapshot:snapshot
    };

    const { error } = await supabase
      .from("mission_steps")
      .update({ step_options_json:options })
      .eq("id", step.id);
    if (error) throw error;
  }));
}

export async function saveQuizForSpace(teacherSpaceId, quiz = {}) {
  const isSystem = quiz?.is_system === true;
  const spaceId = isSystem ? null : normalizePositiveTeacherSpaceId(teacherSpaceId);
  const title = cleanDisplayName(quiz.title) || "Quiz sans titre";
  const existingId = normalizeUuid(quiz.id);
  const now = new Date().toISOString();
  const schemaVersion = Math.max(1, Math.trunc(Number(quiz.version || quiz.schemaVersion || 1) || 1));
  const document = cloneJsonValue({
    ...quiz,
    version: schemaVersion,
    title,
    is_system: isSystem
  });
  const linkedResourceIds = collectQuizResourceIds(document);
  if (isSystem && hasForbiddenSystemQuizSource(document)) {
    throw new Error("Un quiz système ne peut pas utiliser de fichiers locaux au navigateur.");
  }
  if (isSystem) await assertSystemQuizResourcesAreSystem(linkedResourceIds);

  const payload = {
    teacher_space_id: spaceId,
    folder_id: normalizeNullableUuid(quiz.folder_id),
    title,
    document,
    schema_version: schemaVersion,
    display_order: Number.isFinite(Number(quiz.display_order)) ? Number(quiz.display_order) : 0,
    is_system: isSystem,
    updated_at: now
  };

  let query;
  if (existingId) {
    query = supabase
      .from("quizzes")
      .update(payload)
      .eq("id", existingId)
      .eq("is_system", isSystem);
    if (!isSystem) query = query.eq("teacher_space_id", spaceId);
  } else {
    query = supabase
      .from("quizzes")
      .insert({ ...payload, created_at: now });
  }

  const { data, error } = await query.select(QUIZ_FIELDS).single();
  if (error) throw error;
  const saved = normalizeQuizRecord(data);
  await syncQuizResourceLinks(saved.id, saved.document || document);
  await refreshDirectQuizMissionStepsForSpace(teacherSpaceId, saved);
  return saved;
}

export async function deleteQuiz(quizId, options = {}) {
  const id = normalizeUuid(quizId);
  if (!id) throw new Error("Quiz invalide.");
  const { error } = await supabase
    .from("quizzes")
    .delete()
    .eq("id", id)
    .eq("is_system", options?.is_system === true);
  if (error) throw error;
}

/* =========================
   RESSOURCES SUPABASE
   ========================= */

function normalizeResourceFolderRecord(row = {}, index = 0) {
  return {
    id: String(row.id || ""),
    teacher_space_id: row.teacher_space_id == null ? null : Number(row.teacher_space_id),
    parent_id: row.parent_id ? String(row.parent_id) : null,
    name: cleanDisplayName(row.name) || "Dossier sans nom",
    metadata: row.metadata && typeof row.metadata === "object" && !Array.isArray(row.metadata)
      ? cloneJsonValue(row.metadata)
      : {},
    display_order: Number.isFinite(Number(row.display_order)) ? Number(row.display_order) : index,
    is_system: row.is_system === true,
    created_at: String(row.created_at || ""),
    updated_at: String(row.updated_at || row.created_at || "")
  };
}

function normalizeResourceRecord(row = {}, index = 0) {
  return {
    id: String(row.id || ""),
    teacher_space_id: row.teacher_space_id == null ? null : Number(row.teacher_space_id),
    folder_id: row.folder_id ? String(row.folder_id) : null,
    title: cleanDisplayName(row.title) || "Ressource sans nom",
    type: ["image", "audio", "seyes"].includes(String(row.resource_type || "image"))
      ? String(row.resource_type || "image")
      : "image",
    storage_bucket: String(row.storage_bucket || TEACHER_RESOURCE_BUCKET),
    storage_path: String(row.storage_path || ""),
    path: String(row.storage_path || ""),
    mime_type: String(row.mime_type || ""),
    size_bytes: Math.max(0, Number(row.size_bytes) || 0),
    width: Math.max(0, Number(row.width) || 0),
    height: Math.max(0, Number(row.height) || 0),
    duration: Math.max(0, Number(row.duration_seconds) || 0),
    alt: String(row.alt_text || row.title || ""),
    tags: Array.isArray(row.tags) ? row.tags.map((tag) => String(tag || "").trim()).filter(Boolean) : [],
    metadata: row.metadata && typeof row.metadata === "object" && !Array.isArray(row.metadata)
      ? cloneJsonValue(row.metadata)
      : {},
    display_order: Number.isFinite(Number(row.display_order)) ? Number(row.display_order) : index,
    is_system: row.is_system === true,
    scope: row.is_system === true ? "system" : "personal",
    created_at: String(row.created_at || ""),
    updated_at: String(row.updated_at || row.created_at || "")
  };
}

export async function listResourceFoldersForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("resource_folders")
    .select(RESOURCE_FOLDER_FIELDS)
    .or(`teacher_space_id.eq.${spaceId},is_system.eq.true`)
    .order("is_system", { ascending: true })
    .order("display_order", { ascending: true })
    .order("name", { ascending: true });
  if (error) throw error;
  return (Array.isArray(data) ? data : []).map(normalizeResourceFolderRecord);
}

export async function createResourceFolderForSpace(teacherSpaceId, folder = {}) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const name = cleanDisplayName(folder.name);
  if (!name) throw new Error("Nom de dossier vide.");
  const { data, error } = await supabase
    .from("resource_folders")
    .insert({
      teacher_space_id: spaceId,
      parent_id: normalizeNullableUuid(folder.parent_id),
      name,
      metadata: folder.metadata && typeof folder.metadata === "object" && !Array.isArray(folder.metadata)
        ? cloneJsonValue(folder.metadata)
        : {},
      display_order: Number.isFinite(Number(folder.display_order)) ? Number(folder.display_order) : 0,
      is_system: false
    })
    .select(RESOURCE_FOLDER_FIELDS)
    .single();
  if (error) throw error;
  return normalizeResourceFolderRecord(data);
}

export async function createSystemResourceFolderAsAdmin(folder = {}) {
  const name = cleanDisplayName(folder.name);
  if (!name) throw new Error("Nom de dossier vide.");
  const metadata = folder.metadata && typeof folder.metadata === "object" && !Array.isArray(folder.metadata)
    ? cloneJsonValue(folder.metadata)
    : {};
  const { data, error } = await supabase
    .from("resource_folders")
    .insert({
      teacher_space_id: null,
      parent_id: normalizeNullableUuid(folder.parent_id),
      name,
      metadata: { ...metadata, resource_type:"image" },
      display_order: Number.isFinite(Number(folder.display_order)) ? Number(folder.display_order) : 0,
      is_system: true
    })
    .select(RESOURCE_FOLDER_FIELDS)
    .single();
  if (error) throw error;
  return normalizeResourceFolderRecord(data);
}

export async function ensureRecordingsResourceFolderForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const findExisting = async () => {
    const { data, error } = await supabase
      .from("resource_folders")
      .select(RESOURCE_FOLDER_FIELDS)
      .eq("teacher_space_id", spaceId)
      .eq("is_system", false)
      .contains("metadata", { system_role: "recordings" })
      .limit(1);
    if (error) throw error;
    const row = Array.isArray(data) ? data[0] : null;
    return row ? normalizeResourceFolderRecord(row) : null;
  };

  const existing = await findExisting();
  if (existing) return existing;

  const folders = await listResourceFoldersForSpace(spaceId);
  const rootFolders = folders.filter((folder) => folder?.is_system !== true && !folder?.parent_id);
  try {
    return await createResourceFolderForSpace(spaceId, {
      name: "Enregistrements",
      parent_id: null,
      display_order: rootFolders.length,
      metadata: { system_role: "recordings" }
    });
  } catch (error) {
    if (String(error?.code || "") !== "23505") throw error;
    const concurrent = await findExisting();
    if (concurrent) return concurrent;
    throw error;
  }
}

export async function updateResourceFolder(folderId, updates = {}, options = {}) {
  const id = normalizeUuid(folderId);
  if (!id) throw new Error("Dossier de ressources invalide.");
  const payload = {};
  if ("name" in updates) {
    const name = cleanDisplayName(updates.name);
    if (!name) throw new Error("Nom de dossier vide.");
    payload.name = name;
  }
  if ("parent_id" in updates) payload.parent_id = normalizeNullableUuid(updates.parent_id);
  if ("display_order" in updates) payload.display_order = Number(updates.display_order) || 0;
  if ("metadata" in updates) {
    payload.metadata = updates.metadata && typeof updates.metadata === "object" && !Array.isArray(updates.metadata)
      ? cloneJsonValue(updates.metadata)
      : {};
  }
  const isSystem = options?.is_system === true;
  const { data, error } = await supabase
    .from("resource_folders")
    .update(payload)
    .eq("id", id)
    .eq("is_system", isSystem)
    .select(RESOURCE_FOLDER_FIELDS)
    .single();
  if (error) throw error;
  return normalizeResourceFolderRecord(data);
}

export async function deleteResourceFolder(folderId, options = {}) {
  const id = normalizeUuid(folderId);
  if (!id) throw new Error("Dossier de ressources invalide.");
  const { error } = await supabase
    .from("resource_folders")
    .delete()
    .eq("id", id)
    .eq("is_system", options?.is_system === true);
  if (error) throw error;
}

export async function listResourcesForSpace(teacherSpaceId) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  const { data, error } = await supabase
    .from("resources")
    .select(RESOURCE_FIELDS)
    .or(`teacher_space_id.eq.${spaceId},is_system.eq.true`)
    .order("is_system", { ascending: true })
    .order("display_order", { ascending: true })
    .order("title", { ascending: true });
  if (error) throw error;
  return (Array.isArray(data) ? data : []).map(normalizeResourceRecord);
}

function sanitizeStorageFileName(value, fallback = "resource") {
  const source = String(value || fallback).trim() || fallback;
  const normalized = source.normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
  const safe = normalized
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^[-.]+|[-.]+$/g, "");
  return safe || fallback;
}

export async function uploadResourceForSpace(teacherSpaceId, file, resource = {}) {
  const spaceId = normalizePositiveTeacherSpaceId(teacherSpaceId);
  if (!(file instanceof Blob)) throw new Error("Fichier de ressource invalide.");
  const declaredType = String(resource.type || "").trim().toLowerCase();
  const fileNameLower = String(file.name || "").trim().toLowerCase();
  const rawMimeType = String(file.type || resource.mime_type || "").trim().toLowerCase();
  const isSeyes = declaredType === "seyes"
    || rawMimeType === "application/vnd.site-outils.seyes+json"
    || fileNameLower.endsWith(".seyes");
  const mimeType = isSeyes
    ? "application/vnd.site-outils.seyes+json"
    : rawMimeType;
  const resourceType = isSeyes
    ? "seyes"
    : (mimeType.startsWith("audio/") || declaredType === "audio" ? "audio" : "image");
  if (!isSeyes && !mimeType.startsWith("image/") && !mimeType.startsWith("audio/")) {
    throw new Error("Seules les images, les pistes audio et les documents .seyes sont acceptés.");
  }

  const user = await getCurrentUser();
  if (!user?.id) throw new Error("Utilisateur non connecté.");
  const resourceId = globalThis.crypto?.randomUUID?.();
  if (!resourceId) throw new Error("Impossible de générer l’identifiant de la ressource.");
  const fallbackFileName = resourceType === "audio" ? "audio" : (resourceType === "seyes" ? "document.seyes" : "image");
  const fileName = sanitizeStorageFileName(resource.name || file.name, fallbackFileName);
  const storagePath = `${user.id}/${resourceId}/${fileName}`;

  const { error: uploadError } = await supabase.storage
    .from(TEACHER_RESOURCE_BUCKET)
    .upload(storagePath, file, {
      contentType: mimeType,
      cacheControl: "3600",
      upsert: false
    });
  if (uploadError) throw uploadError;

  const payload = {
    id: resourceId,
    teacher_space_id: spaceId,
    folder_id: normalizeNullableUuid(resource.folder_id),
    title: cleanDisplayName(resource.title || file.name) || (resourceType === "audio" ? "Audio" : (resourceType === "seyes" ? "Document Seyès" : "Image")),
    resource_type: resourceType,
    storage_bucket: TEACHER_RESOURCE_BUCKET,
    storage_path: storagePath,
    mime_type: mimeType,
    size_bytes: Math.max(0, Number(file.size) || 0),
    width: Math.max(0, Number(resource.width) || 0),
    height: Math.max(0, Number(resource.height) || 0),
    duration_seconds: Math.max(0, Number(resource.duration) || 0),
    alt_text: String(resource.alt || resource.title || file.name || "").trim(),
    tags: Array.isArray(resource.tags) ? resource.tags.map((tag) => String(tag || "").trim()).filter(Boolean) : [],
    metadata: resource.metadata && typeof resource.metadata === "object" && !Array.isArray(resource.metadata)
      ? cloneJsonValue(resource.metadata)
      : {},
    display_order: Number.isFinite(Number(resource.display_order)) ? Number(resource.display_order) : 0,
    is_system: false
  };

  const { data, error } = await supabase
    .from("resources")
    .insert(payload)
    .select(RESOURCE_FIELDS)
    .single();

  if (error) {
    await supabase.storage.from(TEACHER_RESOURCE_BUCKET).remove([storagePath]).catch(() => {});
    throw error;
  }

  return normalizeResourceRecord(data);
}

export async function replaceAudioResourceFile(resourceId, file, updates = {}) {
  const id = normalizeUuid(resourceId);
  if (!id) throw new Error("Ressource audio invalide.");
  if (!(file instanceof Blob)) throw new Error("Fichier audio invalide.");
  const mimeType = String(file.type || updates.mime_type || "").trim().toLowerCase();
  if (!mimeType.startsWith("audio/")) throw new Error("Le nouveau fichier doit être un audio.");

  const { data: existing, error: readError } = await supabase
    .from("resources")
    .select(RESOURCE_FIELDS)
    .eq("id", id)
    .eq("is_system", false)
    .single();
  if (readError) throw readError;
  if (String(existing?.resource_type || "") !== "audio") throw new Error("Cette ressource n’est pas un audio personnel.");

  const user = await getCurrentUser();
  if (!user?.id) throw new Error("Utilisateur non connecté.");
  const bucket = String(existing?.storage_bucket || TEACHER_RESOURCE_BUCKET).trim() || TEACHER_RESOURCE_BUCKET;
  const extension = (() => {
    const value = mimeType.toLowerCase();
    if (value.includes("ogg")) return "ogg";
    if (value.includes("mp4") || value.includes("m4a")) return "m4a";
    if (value.includes("wav")) return "wav";
    if (value.includes("mpeg") || value.includes("mp3")) return "mp3";
    return "webm";
  })();
  const storagePath = `${user.id}/${id}/audio-${Date.now()}.${extension}`;

  const { error: uploadError } = await supabase.storage
    .from(bucket)
    .upload(storagePath, file, {
      contentType: mimeType,
      cacheControl: "3600",
      upsert: false
    });
  if (uploadError) throw uploadError;

  const existingMetadata = existing?.metadata && typeof existing.metadata === "object" && !Array.isArray(existing.metadata)
    ? cloneJsonValue(existing.metadata)
    : {};
  const replacementMetadata = updates?.metadata && typeof updates.metadata === "object" && !Array.isArray(updates.metadata)
    ? cloneJsonValue(updates.metadata)
    : {};
  const payload = {
    storage_bucket: bucket,
    storage_path: storagePath,
    mime_type: mimeType,
    size_bytes: Math.max(0, Number(file.size) || 0),
    width: 0,
    height: 0,
    duration_seconds: Math.max(0, Number(updates.duration) || 0),
    metadata: {
      ...existingMetadata,
      ...replacementMetadata,
      replaced_at: new Date().toISOString()
    }
  };
  if ("title" in updates) {
    const title = cleanDisplayName(updates.title);
    if (title) payload.title = title;
  }
  if ("alt" in updates || "alt_text" in updates) {
    payload.alt_text = String(updates.alt_text ?? updates.alt ?? "").trim();
  }

  const { data, error } = await supabase
    .from("resources")
    .update(payload)
    .eq("id", id)
    .eq("is_system", false)
    .select(RESOURCE_FIELDS)
    .single();
  if (error) {
    await supabase.storage.from(bucket).remove([storagePath]).catch(() => {});
    throw error;
  }

  const oldBucket = String(existing?.storage_bucket || bucket).trim() || bucket;
  const oldPath = String(existing?.storage_path || "").trim();
  if (oldPath && (oldBucket !== bucket || oldPath !== storagePath)) {
    const { error: removeError } = await supabase.storage.from(oldBucket).remove([oldPath]);
    if (removeError) console.warn("Le nouvel audio est enregistré, mais l’ancien fichier Storage n’a pas pu être supprimé.", removeError);
  }

  return normalizeResourceRecord(data);
}

export async function updateResource(resourceId, updates = {}, options = {}) {
  const id = normalizeUuid(resourceId);
  if (!id) throw new Error("Ressource invalide.");

  const payload = {};
  if ("folder_id" in updates) payload.folder_id = normalizeNullableUuid(updates.folder_id);
  if ("display_order" in updates) payload.display_order = Number(updates.display_order) || 0;
  if ("title" in updates) {
    const title = cleanDisplayName(updates.title);
    if (!title) throw new Error("Nom de ressource vide.");
    payload.title = title;
  }
  if ("alt" in updates || "alt_text" in updates) {
    payload.alt_text = String(updates.alt_text ?? updates.alt ?? "").trim();
  }
  if ("tags" in updates) {
    payload.tags = Array.isArray(updates.tags)
      ? updates.tags.map((tag) => String(tag || "").trim()).filter(Boolean)
      : [];
  }
  if ("metadata" in updates) {
    payload.metadata = updates.metadata && typeof updates.metadata === "object" && !Array.isArray(updates.metadata)
      ? cloneJsonValue(updates.metadata)
      : {};
  }

  const isSystem = options?.is_system === true;

  if (!Object.keys(payload).length) {
    const { data, error } = await supabase
      .from("resources")
      .select(RESOURCE_FIELDS)
      .eq("id", id)
      .eq("is_system", isSystem)
      .single();
    if (error) throw error;
    return normalizeResourceRecord(data);
  }

  const { data, error } = await supabase
    .from("resources")
    .update(payload)
    .eq("id", id)
    .eq("is_system", isSystem)
    .select(RESOURCE_FIELDS)
    .single();
  if (error) throw error;
  return normalizeResourceRecord(data);
}

export async function createResourceSignedUrl(resource, expiresInSeconds = 3600) {
  const bucket = String(resource?.storage_bucket || TEACHER_RESOURCE_BUCKET).trim();
  const path = String(resource?.storage_path || resource?.path || "").trim();
  if (!path) return "";
  if (bucket === SYSTEM_IMAGE_BUCKET) {
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return String(data?.publicUrl || "");
  }
  const expiresIn = Math.max(60, Math.min(86400, Math.trunc(Number(expiresInSeconds) || 3600)));
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, expiresIn);
  if (error) throw error;
  return String(data?.signedUrl || "");
}

export async function deleteResource(resourceId, options = {}) {
  const id = normalizeUuid(resourceId);
  if (!id) throw new Error("Ressource invalide.");

  if (options?.is_system === true) {
    const { data, error } = await supabase.rpc("delete_system_image_asset_as_admin", {
      p_resource_id: id
    });
    if (error) throw error;

    const bucket = String(data?.storage_bucket || SYSTEM_IMAGE_BUCKET).trim() || SYSTEM_IMAGE_BUCKET;
    const path = String(data?.storage_path || "").trim();
    if (path) {
      const { error: storageError } = await supabase.storage.from(bucket).remove([path]);
      if (storageError) {
        console.warn("L’image a été supprimée de la base, mais son fichier Storage n’a pas pu être effacé.", storageError);
      }
    }
    return data && typeof data === "object" ? data : {};
  }

  const { data: resource, error: readError } = await supabase
    .from("resources")
    .select(RESOURCE_FIELDS)
    .eq("id", id)
    .eq("is_system", false)
    .single();
  if (readError) throw readError;

  const { error: deleteError } = await supabase
    .from("resources")
    .delete()
    .eq("id", id)
    .eq("is_system", false);
  if (deleteError) throw deleteError;

  const bucket = String(resource?.storage_bucket || TEACHER_RESOURCE_BUCKET);
  const path = String(resource?.storage_path || "");
  if (path) {
    const { error: storageError } = await supabase.storage.from(bucket).remove([path]);
    if (storageError) console.warn("La ligne a été supprimée, mais le fichier Storage n’a pas pu être effacé.", storageError);
  }
  return resource;
}


// ---------------------------------------------------------
// Banque lexicale définitive
// ---------------------------------------------------------

const LEXICAL_ENTRY_FIELDS = "id, entry_key, entry, category, lexical_level, phonology, syllabifications, introducers, masc_sing, fem_sing, masc_plur, fem_plur, is_active, created_at, updated_at";

function normalizeLexicalEntryKey(value) {
  return String(value || "").trim().normalize("NFC").toLocaleLowerCase("fr-FR");
}

function normalizeLexicalStringArray(value) {
  return Array.from(new Set(
    (Array.isArray(value) ? value : [])
      .map((item) => String(item || "").trim().normalize("NFC"))
      .filter(Boolean)
  ));
}

function normalizeNullableLexicalText(value) {
  const text = String(value || "").trim().normalize("NFC");
  return text || null;
}

function normalizeLexicalLevel(value) {
  const level = Number(value);
  return Number.isInteger(level) && level >= 1 && level <= 3 ? level : 0;
}

function normalizeLexicalEntryRecord(row = {}) {
  return {
    id: row?.id ? String(row.id) : null,
    entry_key: normalizeLexicalEntryKey(row?.entry_key || row?.entry),
    entry: String(row?.entry || "").trim().normalize("NFC"),
    category: String(row?.category || "").trim().normalize("NFC").toLocaleLowerCase("fr-FR"),
    lexical_level: normalizeLexicalLevel(row?.lexical_level),
    phonology: normalizeLexicalStringArray(row?.phonology),
    syllabifications: normalizeLexicalStringArray(row?.syllabifications),
    introducers: normalizeLexicalStringArray(row?.introducers),
    masc_sing: normalizeNullableLexicalText(row?.masc_sing),
    fem_sing: normalizeNullableLexicalText(row?.fem_sing),
    masc_plur: normalizeNullableLexicalText(row?.masc_plur),
    fem_plur: normalizeNullableLexicalText(row?.fem_plur),
    is_active: row?.is_active !== false,
    created_at: String(row?.created_at || ""),
    updated_at: String(row?.updated_at || row?.created_at || "")
  };
}

function buildLexicalEntryPayload(row = {}) {
  const normalized = normalizeLexicalEntryRecord(row);
  if (!normalized.entry || !normalized.entry_key) throw new Error("Entrée lexicale vide.");
  if (!normalized.category) throw new Error(`Catégorie manquante pour « ${normalized.entry} ».`);
  if (![1, 2, 3].includes(normalized.lexical_level)) {
    throw new Error(`Niveau lexical invalide pour « ${normalized.entry} ».`);
  }
  return {
    entry_key: normalized.entry_key,
    entry: normalized.entry,
    category: normalized.category,
    lexical_level: normalized.lexical_level,
    phonology: normalized.phonology,
    syllabifications: normalized.syllabifications,
    introducers: normalized.introducers,
    masc_sing: normalized.masc_sing,
    fem_sing: normalized.fem_sing,
    masc_plur: normalized.masc_plur,
    fem_plur: normalized.fem_plur,
    is_active: normalized.is_active
  };
}

export async function getLexicalEntriesCount() {
  const { count, error } = await supabase
    .from("lexical_entries")
    .select("id", { count:"exact", head:true })
    .eq("is_active", true);
  if (error) throw error;
  return Math.max(0, Number(count) || 0);
}

export async function listLexicalEntries() {
  const pageSize = 1000;
  const rows = [];
  for (let from = 0; ; from += pageSize) {
    const { data, error } = await supabase
      .from("lexical_entries")
      .select(LEXICAL_ENTRY_FIELDS)
      .order("entry_key", { ascending:true })
      .range(from, from + pageSize - 1);
    if (error) throw error;
    const page = Array.isArray(data) ? data : [];
    rows.push(...page);
    if (page.length < pageSize) break;
  }
  return rows.map(normalizeLexicalEntryRecord);
}

export async function saveLexicalEntryAsAdmin(entry = {}) {
  if (!(await isCurrentUserSuperAdmin())) throw new Error("Accès super-admin requis.");
  const payload = buildLexicalEntryPayload(entry);
  const id = normalizeUuid(entry?.id);
  let query = null;
  if (id) {
    query = supabase
      .from("lexical_entries")
      .update(payload)
      .eq("id", id);
  } else {
    query = supabase
      .from("lexical_entries")
      .insert(payload);
  }
  const { data, error } = await query.select(LEXICAL_ENTRY_FIELDS).single();
  if (error) throw error;
  return normalizeLexicalEntryRecord(data);
}

export async function upsertLexicalEntriesAsAdmin(entries = []) {
  if (!(await isCurrentUserSuperAdmin())) throw new Error("Accès super-admin requis.");
  const payload = (Array.isArray(entries) ? entries : []).map(buildLexicalEntryPayload);
  if (!payload.length) throw new Error("Aucun mot à importer.");

  const chunkSize = 500;
  const imported = [];
  for (let index = 0; index < payload.length; index += chunkSize) {
    const chunk = payload.slice(index, index + chunkSize);
    const { data, error } = await supabase
      .from("lexical_entries")
      .upsert(chunk, { onConflict:"entry_key" })
      .select(LEXICAL_ENTRY_FIELDS);
    if (error) throw error;
    imported.push(...(Array.isArray(data) ? data : []));
  }
  return imported.map(normalizeLexicalEntryRecord);
}

export async function deleteLexicalEntryAsAdmin(entryId) {
  if (!(await isCurrentUserSuperAdmin())) throw new Error("Accès super-admin requis.");
  const id = normalizeUuid(entryId);
  if (!id) throw new Error("Entrée lexicale invalide.");
  const { error } = await supabase
    .from("lexical_entries")
    .delete()
    .eq("id", id);
  if (error) throw error;
  return true;
}

function normalizeImageAssetRecord(row = {}) {
  return {
    slug: String(row.slug || "").trim().toLowerCase(),
    word_slug: String(row.word_slug || "").trim().toLocaleLowerCase("fr-FR"),
    resource_id: row.resource_id ? String(row.resource_id) : null,
    storage_path: String(row.storage_path || "").trim(),
    tags: Array.isArray(row.tags) ? row.tags.map((tag) => String(tag || "").trim()).filter(Boolean) : [],
    notes: String(row.notes || "").trim(),
    metadata: row.metadata && typeof row.metadata === "object" && !Array.isArray(row.metadata)
      ? cloneJsonValue(row.metadata)
      : {},
    is_active: row.is_active !== false,
    created_at: String(row.created_at || ""),
    updated_at: String(row.updated_at || row.created_at || "")
  };
}

export async function listImageAssetsAsAdmin() {
  const pageSize = 1000;
  const rows = [];

  for (let from = 0; ; from += pageSize) {
    const to = from + pageSize - 1;
    const { data, error } = await supabase
      .from("image_assets")
      .select("slug, word_slug, resource_id, storage_path, tags, notes, metadata, is_active, created_at, updated_at")
      .order("slug", { ascending: true })
      .range(from, to);
    if (error) throw error;
    const page = Array.isArray(data) ? data : [];
    rows.push(...page);
    if (page.length < pageSize) break;
  }

  return rows.map(normalizeImageAssetRecord);
}

export async function listLexicalWordLexiconAsAdmin() {
  const pageSize = 1000;
  const rows = [];

  for (let from = 0; ; from += pageSize) {
    const to = from + pageSize - 1;
    const { data, error } = await supabase
      .from("lexical_entries")
      .select("entry_key, entry")
      .eq("is_active", true)
      .order("entry_key", { ascending: true })
      .range(from, to);
    if (error) throw error;
    const page = Array.isArray(data) ? data : [];
    rows.push(...page);
    if (page.length < pageSize) break;
  }

  return rows
    .map((row) => ({
      slug: String(row?.entry_key || "").trim().normalize("NFC").toLocaleLowerCase("fr-FR"),
      word: String(row?.entry || "").trim().normalize("NFC")
    }))
    .filter((row) => row.slug && row.word);
}

function isDuplicateStorageObjectError(error) {
  const code = String(error?.code || error?.statusCode || "").toLowerCase();
  const message = String(error?.message || "").toLowerCase();
  return code === "409" || code === "duplicate" || message.includes("duplicate") || message.includes("already exists");
}

export async function importSystemImageAssetAsAdmin(file, asset = {}) {
  if (!(file instanceof Blob)) throw new Error("Fichier image invalide.");
  const slug = String(asset.slug || "").trim().toLowerCase();
  const wordSlug = String(asset.word_slug || "").trim().normalize("NFC").toLocaleLowerCase("fr-FR");
  const storagePath = String(asset.storage_path || "").trim();
  const mimeType = String(file.type || asset?.metadata?.mime_type || "").trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9_-]{0,119}$/.test(slug)) throw new Error("Identifiant d’image invalide.");
  if (!storagePath.startsWith(`bank/${slug}/`)) throw new Error("Chemin Storage invalide.");
  if (!wordSlug) throw new Error("Mot associé manquant.");
  if (!mimeType.startsWith("image/")) throw new Error("Le fichier sélectionné n’est pas une image.");

  let uploadedNewObject = false;
  const { error: uploadError } = await supabase.storage
    .from(SYSTEM_IMAGE_BUCKET)
    .upload(storagePath, file, {
      contentType: mimeType,
      cacheControl: "31536000",
      upsert: false
    });
  if (uploadError && !isDuplicateStorageObjectError(uploadError)) throw uploadError;
  uploadedNewObject = !uploadError;

  const tags = Array.isArray(asset.tags) ? asset.tags.map((tag) => String(tag || "").trim()).filter(Boolean) : [];
  const metadata = asset.metadata && typeof asset.metadata === "object" && !Array.isArray(asset.metadata)
    ? cloneJsonValue(asset.metadata)
    : {};
  const { data, error } = await supabase.rpc("upsert_system_image_asset_as_admin", {
    p_slug: slug,
    p_storage_path: storagePath,
    p_tags: tags,
    p_notes: String(asset.notes || "").trim(),
    p_metadata: metadata,
    p_folder_path: String(asset.folder_path || "").trim(),
    p_word_slug: wordSlug
  });

  if (error) {
    if (uploadedNewObject) {
      await supabase.storage.from(SYSTEM_IMAGE_BUCKET).remove([storagePath]).catch(() => {});
    }
    throw error;
  }

  const previousStoragePath = String(asset.previous_storage_path || "").trim();
  if (previousStoragePath && previousStoragePath !== storagePath && previousStoragePath.startsWith("bank/")) {
    const { error: cleanupError } = await supabase.storage.from(SYSTEM_IMAGE_BUCKET).remove([previousStoragePath]);
    if (cleanupError) console.warn("L’image a été remplacée, mais l’ancienne version Storage n’a pas pu être supprimée.", cleanupError);
  }

  return normalizeImageAssetRecord(data);
}



// ---------------------------------------------------------
// Entrées audio dynamiques de l’Imagier (super-admin)
// ---------------------------------------------------------

export async function listImagierAudioEntriesAsAdmin() {
  if (!(await isCurrentUserSuperAdmin())) throw new Error("Accès super-admin requis.");

  const [folderResult, resourceResult, assetRows, lexiconRows] = await Promise.all([
    supabase
      .from("resource_folders")
      .select(RESOURCE_FOLDER_FIELDS)
      .eq("is_system", true)
      .order("display_order", { ascending:true })
      .order("name", { ascending:true }),
    supabase
      .from("resources")
      .select(RESOURCE_FIELDS)
      .eq("is_system", true)
      .eq("resource_type", "image")
      .eq("storage_bucket", SYSTEM_IMAGE_BUCKET)
      .order("display_order", { ascending:true })
      .order("title", { ascending:true }),
    listImageAssetsAsAdmin(),
    listLexicalWordLexiconAsAdmin()
  ]);

  if (folderResult.error) throw folderResult.error;
  if (resourceResult.error) throw resourceResult.error;

  const folders = (Array.isArray(folderResult.data) ? folderResult.data : []).map(normalizeResourceFolderRecord);
  const resources = (Array.isArray(resourceResult.data) ? resourceResult.data : []).map(normalizeResourceRecord);
  const assets = Array.isArray(assetRows) ? assetRows : [];
  const lexicon = Array.isArray(lexiconRows) ? lexiconRows : [];

  const imagesRoot = folders.find((folder) => String(folder?.metadata?.system_role || "") === "system_images_root") || null;
  if (!imagesRoot?.id) return [];

  const imagierRoot = folders.find((folder) =>
    folder?.is_system === true
    && String(folder?.parent_id || "") === String(imagesRoot.id)
    && String(folder?.name || "").trim().localeCompare("Imagier", "fr", { sensitivity:"base" }) === 0
  ) || null;
  if (!imagierRoot?.id) return [];

  const childrenByParent = new Map();
  for (const folder of folders) {
    const parentId = String(folder?.parent_id || "");
    if (!parentId) continue;
    const list = childrenByParent.get(parentId) || [];
    list.push(folder);
    childrenByParent.set(parentId, list);
  }

  const imagierFolderIds = new Set();
  const queue = [imagierRoot];
  while (queue.length) {
    const folder = queue.shift();
    const folderId = String(folder?.id || "");
    if (!folderId || imagierFolderIds.has(folderId)) continue;
    imagierFolderIds.add(folderId);
    for (const child of childrenByParent.get(folderId) || []) queue.push(child);
  }

  const folderById = new Map(folders.map((folder) => [String(folder?.id || ""), folder]));
  const buildFolderPath = (folderId) => {
    const parts = [];
    const visited = new Set();
    let cursor = folderById.get(String(folderId || "")) || null;
    while (cursor) {
      const cursorId = String(cursor?.id || "");
      if (!cursorId || visited.has(cursorId)) break;
      visited.add(cursorId);
      if (cursorId === String(imagierRoot.id)) break;
      parts.unshift(String(cursor?.name || "").trim());
      cursor = folderById.get(String(cursor?.parent_id || "")) || null;
    }
    return parts.filter(Boolean).join(" / ");
  };

  const resourcesById = new Map(
    resources
      .filter((resource) => imagierFolderIds.has(String(resource?.folder_id || "")))
      .map((resource) => [String(resource?.id || ""), resource])
  );
  const wordsBySlug = new Map(
    lexicon
      .map((row) => [
        String(row?.slug || "").trim().normalize("NFC").toLocaleLowerCase("fr-FR"),
        String(row?.word || "").trim().normalize("NFC")
      ])
      .filter(([slug, word]) => slug && word)
  );

  const entries = [];
  for (const asset of assets) {
    if (asset?.is_active === false) continue;
    const resource = resourcesById.get(String(asset?.resource_id || "")) || null;
    if (!resource) continue;

    const imageSlug = String(asset?.slug || resource?.metadata?.image_asset_slug || "").trim().toLowerCase();
    if (!imageSlug) continue;
    const wordSlug = String(asset?.word_slug || resource?.metadata?.image_word_slug || "")
      .trim()
      .normalize("NFC")
      .toLocaleLowerCase("fr-FR");
    const word = String(
      wordsBySlug.get(wordSlug)
      || asset?.metadata?.image_word
      || resource?.metadata?.image_word
      || resource?.title
      || wordSlug
      || imageSlug
    ).trim().normalize("NFC");
    if (!word) continue;

    const storagePath = String(asset?.storage_path || resource?.storage_path || "").trim();
    const { data:urlData } = storagePath
      ? supabase.storage.from(SYSTEM_IMAGE_BUCKET).getPublicUrl(storagePath)
      : { data:null };

    entries.push({
      key: `imagier.${imageSlug}`,
      category: "Imagier",
      label: word,
      text: word,
      imageSlug,
      imageUrl: String(urlData?.publicUrl || "").trim(),
      imagierFolderId: String(resource?.folder_id || imagierRoot.id),
      imagierFolderPath: buildFolderPath(resource?.folder_id),
      resourceId: String(resource?.id || "")
    });
  }

  return entries.sort((a, b) => {
    const folderCompare = String(a.imagierFolderPath || "").localeCompare(String(b.imagierFolderPath || ""), "fr", { sensitivity:"base", numeric:true });
    if (folderCompare) return folderCompare;
    const wordCompare = String(a.label || "").localeCompare(String(b.label || ""), "fr", { sensitivity:"base", numeric:true });
    if (wordCompare) return wordCompare;
    return String(a.imageSlug || "").localeCompare(String(b.imageSlug || ""), "fr", { sensitivity:"base", numeric:true });
  });
}

// ---------------------------------------------------------
// Centre audio système (super-admin)
// ---------------------------------------------------------

const INTERFACE_AUDIO_BUCKET = "interface-audio";
const INTERFACE_AUDIO_FIELDS = "owner_key, audio_key, teacher_space_id, title, source_text, storage_bucket, storage_path, mime_type, size_bytes, duration_seconds, metadata, created_at, updated_at";

export async function listInterfaceAudioAssetsAsAdmin() {
  const { data, error } = await supabase
    .from("interface_audio_assets")
    .select(INTERFACE_AUDIO_FIELDS)
    .eq("owner_key", "system")
    .order("audio_key", { ascending:true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function uploadSystemInterfaceAudioAsAdmin(audioKey, blob, meta = {}) {
  const key = String(audioKey || "").trim();
  if (!key) throw new Error("Clé audio invalide.");
  if (!(blob instanceof Blob)) throw new Error("Enregistrement audio invalide.");
  if (!String(blob.type || meta.mimeType || "").toLowerCase().startsWith("audio/")) {
    throw new Error("Le fichier enregistré n’est pas un audio.");
  }
  if (!(await isCurrentUserSuperAdmin())) throw new Error("Accès super-admin requis.");

  const existingRows = await listInterfaceAudioAssetsAsAdmin();
  const existing = existingRows.find((row) => String(row.audio_key || "") === key) || null;
  const extension = getInterfaceAudioExtension(blob.type || meta.mimeType);
  const objectId = globalThis.crypto?.randomUUID?.();
  if (!objectId) throw new Error("Impossible de générer l’identifiant du fichier audio.");
  const safeKey = sanitizeStorageFileName(key.replaceAll(".", "-"), "audio");
  const storagePath = `system/${safeKey}/${objectId}.${extension}`;
  const mimeType = String(blob.type || meta.mimeType || "audio/webm").trim() || "audio/webm";

  const { error: uploadError } = await supabase.storage
    .from(INTERFACE_AUDIO_BUCKET)
    .upload(storagePath, blob, {
      contentType:mimeType,
      cacheControl:"3600",
      upsert:false
    });
  if (uploadError) throw uploadError;

  const payload = {
    owner_key:"system",
    audio_key:key,
    teacher_space_id:null,
    title:cleanDisplayName(meta.title || key) || key,
    source_text:String(meta.text || "").trim(),
    storage_bucket:INTERFACE_AUDIO_BUCKET,
    storage_path:storagePath,
    mime_type:mimeType,
    size_bytes:Math.max(0, Number(blob.size) || 0),
    duration_seconds:Math.max(0, Number(meta.duration) || 0),
    metadata:{
      origin:"interface-audio-admin",
      recorded_at:new Date().toISOString(),
      ...(meta.metadata && typeof meta.metadata === "object" && !Array.isArray(meta.metadata)
        ? cloneJsonValue(meta.metadata)
        : {})
    }
  };

  const { data, error } = await supabase
    .from("interface_audio_assets")
    .upsert(payload, { onConflict:"owner_key,audio_key" })
    .select(INTERFACE_AUDIO_FIELDS)
    .single();
  if (error) {
    await supabase.storage.from(INTERFACE_AUDIO_BUCKET).remove([storagePath]).catch(() => {});
    throw error;
  }

  const oldPath = String(existing?.storage_path || "").trim();
  if (oldPath && oldPath !== storagePath) {
    const { error: removeError } = await supabase.storage.from(INTERFACE_AUDIO_BUCKET).remove([oldPath]);
    if (removeError) console.warn("Ancien fichier audio système non supprimé.", removeError);
  }
  return data || null;
}

export async function deleteSystemInterfaceAudioAsAdmin(audioKey) {
  const key = String(audioKey || "").trim();
  if (!key) throw new Error("Clé audio invalide.");
  if (!(await isCurrentUserSuperAdmin())) throw new Error("Accès super-admin requis.");

  const { data:rows, error:readError } = await supabase
    .from("interface_audio_assets")
    .select(INTERFACE_AUDIO_FIELDS)
    .eq("owner_key", "system")
    .eq("audio_key", key)
    .limit(1);
  if (readError) throw readError;
  const existing = Array.isArray(rows) ? rows[0] : null;

  const { error } = await supabase
    .from("interface_audio_assets")
    .delete()
    .eq("owner_key", "system")
    .eq("audio_key", key);
  if (error) throw error;

  const path = String(existing?.storage_path || "").trim();
  if (path) {
    const { error:storageError } = await supabase.storage.from(INTERFACE_AUDIO_BUCKET).remove([path]);
    if (storageError) console.warn("Ligne audio supprimée mais fichier Storage conservé.", storageError);
  }
  return true;
}

export function getInterfaceAudioAssetPublicUrl(asset = {}) {
  const bucket = String(asset?.storage_bucket || INTERFACE_AUDIO_BUCKET).trim() || INTERFACE_AUDIO_BUCKET;
  const path = String(asset?.storage_path || "").trim();
  if (!path) return "";
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return String(data?.publicUrl || "").trim();
}

function getInterfaceAudioExtension(mimeType) {
  const value = String(mimeType || "").toLowerCase();
  if (value.includes("ogg")) return "ogg";
  if (value.includes("mp4") || value.includes("m4a")) return "m4a";
  if (value.includes("wav")) return "wav";
  if (value.includes("mpeg") || value.includes("mp3")) return "mp3";
  return "webm";
}
